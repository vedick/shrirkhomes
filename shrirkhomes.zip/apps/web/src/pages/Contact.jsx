import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import { useToast } from '@/hooks/use-toast';

const Contact = () => {
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 Feature Coming Soon!",
      description: "Contact form submission will be available soon. You can request it in your next prompt! 🚀",
    });
  };

  const contactInfo = [
    {
      icon: Phone,
      title: 'Phone',
      details: ['+91 7303459116'],
      action: 'tel:+917303459116'
    },
    {
      icon: Mail,
      title: 'Email',
      details: ['sales@shrirkhomes.com'],
      action: 'mailto:sales@shrirkhomes.com'
    },
    {
      icon: MapPin,
      title: 'Address',
      details: ['Noida, Uttar Pradesh', 'India - 201301']
    },
    {
      icon: Clock,
      title: 'Working Hours',
      details: ['Monday - Sunday', '9:00 AM - 8:00 PM']
    }
  ];

  const serviceAreas = [
    { name: 'Noida', sectors: 'Sectors 137, 150, 168, and more' },
    { name: 'Greater Noida', sectors: 'Greater Noida West, Noida Extension, Techzone' },
    { name: 'Yamuna Expressway', sectors: 'Sectors 16, 18, 22, 25' }
  ];

  const whatsappNumber = '917303459116';
  const whatsappMessage = 'Hello! I would like to inquire about properties.';

  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "Shri RK Homes",
    "image": "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a5646/89b66dbe668adcc56bbba4265b131993.jpg",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Noida",
      "addressRegion": "UP",
      "postalCode": "201301",
      "addressCountry": "IN"
    },
    "telephone": "+91-7303459116",
    "email": "sales@shrirkhomes.com",
    "openingHours": "Mo-Su 09:00-20:00",
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+91-7303459116",
      "contactType": "customer service",
      "areaServed": ["Noida", "Greater Noida", "Yamuna Expressway"],
      "availableLanguage": ["en", "hi"]
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact Shri RK Homes - Real Estate Consultant in Noida | +91 7303459116</title>
        <meta name="description" content="Contact Shri RK Homes for premium real estate services in Noida, Greater Noida, and Yamuna Expressway. Call +91 7303459116 or email sales@shrirkhomes.com for property inquiries and site visits." />
        <meta name="keywords" content="contact Shri RK Homes, real estate consultant Noida, property inquiry, site visit booking, Noida real estate contact, Greater Noida properties" />
        <link rel="canonical" href="https://shrirkhomes.com/contact" />
        
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>

      <Header />

      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'Contact Us' }]} />
      </div>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-[#9c4915]/10 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Get in Touch</h1>
            <p className="text-xl text-muted-foreground">
              We're here to help you find your dream property. Reach out to us for personalized assistance.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {contactInfo.map((info, index) => {
              const Icon = info.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="text-center h-full hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="w-14 h-14 bg-[#9c4915]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Icon className="w-7 h-7 text-[#9c4915]" />
                      </div>
                      <h3 className="font-bold mb-2">{info.title}</h3>
                      {info.details.map((detail, idx) => (
                        <p key={idx} className="text-muted-foreground text-sm">
                          {info.action ? (
                            <a href={info.action} className="hover:text-[#9c4915]">{detail}</a>
                          ) : (
                            detail
                          )}
                        </p>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Form & Map */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <Card>
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-6">Send us a Message</h2>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input id="name" placeholder="Enter your name" className="text-gray-900" required />
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input id="email" type="email" placeholder="your@email.com" className="text-gray-900" required />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input id="phone" type="tel" placeholder="+91 XXXXX XXXXX" className="text-gray-900" required />
                    </div>
                    <div>
                      <Label htmlFor="interest">Property Interest</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select property type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="high-rise">High-Rise Apartment</SelectItem>
                          <SelectItem value="builder-floor">Builder Floor</SelectItem>
                          <SelectItem value="commercial">Commercial Property</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="message">Message</Label>
                      <Textarea id="message" placeholder="Tell us about your requirements..." className="text-gray-900" rows={4} />
                    </div>
                    <Button type="submit" className="w-full bg-[#9c4915] hover:bg-[#7a3710]">
                      Send Message
                    </Button>
                  </form>

                  <div className="mt-6 pt-6 border-t">
                    <p className="text-center text-sm text-muted-foreground mb-4">Or reach us directly on WhatsApp</p>
                    <a 
                      href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button className="w-full bg-green-600 hover:bg-green-700">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Chat on WhatsApp
                      </Button>
                    </a>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <Card className="h-full">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-6">Our Location</h2>
                  <div className="bg-gray-200 h-64 rounded-lg flex items-center justify-center mb-6">
                    <p className="text-muted-foreground">Map will be embedded here</p>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-bold mb-2">Service Areas</h3>
                      {serviceAreas.map((area, index) => (
                        <div key={index} className="mb-3">
                          <p className="font-semibold text-[#9c4915]">{area.name}</p>
                          <p className="text-sm text-muted-foreground">{area.sectors}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* SEO Content */}
      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <article className="prose prose-lg max-w-none">
            <h2 className="text-3xl font-bold mb-6">Contact Shri RK Homes for Premium Real Estate Services</h2>
            
            <p className="text-gray-700 mb-6">
              Shri RK Homes is your trusted real estate partner in Noida, Greater Noida, and Yamuna Expressway. Whether you're looking to buy your first home, invest in commercial property, or upgrade to a larger space, our team of experienced property consultants is here to assist you at every step. We provide personalized service, complete RERA guidance, and transparent processes to ensure a smooth property buying experience.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Why Contact Us?</h3>
            <p className="text-gray-700 mb-6">
              When you reach out to Shri RK Homes, you get access to exclusive property listings, expert market insights, and comprehensive support from property search to final handover. Our team understands the local real estate market dynamics and can help you find properties that match your budget, location preferences, and lifestyle requirements. We arrange site visits, assist with documentation, and provide home loan guidance to make your property buying journey hassle-free.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Schedule a Site Visit</h3>
            <p className="text-gray-700 mb-6">
              Experience properties firsthand by scheduling a guided site visit with our experts. We arrange property tours at your convenience and provide detailed information about each property, including amenities, pricing, payment plans, and legal documentation. Call us at +91 7303459116 or fill out the contact form above to book your site visit today.
            </p>
          </article>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default Contact;