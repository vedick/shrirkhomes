import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Target, Eye, Award, TrendingUp, Users, Shield } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';

const MissionVision = () => {
  const milestones = [
    { year: '2015', title: 'Company Founded', description: 'Started operations in Noida with a vision to transform real estate consulting' },
    { year: '2017', title: '100+ Happy Clients', description: 'Reached milestone of serving 100 satisfied homeowners' },
    { year: '2019', title: 'RERA Compliance', description: 'Became fully RERA compliant, ensuring 100% legal properties' },
    { year: '2021', title: 'Expansion', description: 'Extended services to Greater Noida and Yamuna Expressway' },
    { year: '2023', title: '500+ Properties', description: 'Successfully facilitated over 500 property transactions' },
    { year: '2026', title: 'Industry Leader', description: 'Recognized as a leading real estate consultant in NCR' }
  ];

  const coreValues = [
    {
      icon: Shield,
      title: 'Integrity',
      description: 'Honest and ethical practices in all our dealings, maintaining the highest standards of professional conduct.'
    },
    {
      icon: Users,
      title: 'Customer Focus',
      description: 'Putting client needs first, providing personalized solutions and lifetime support for every transaction.'
    },
    {
      icon: Award,
      title: 'Excellence',
      description: 'Commitment to quality in every aspect—from property selection to documentation and after-sales service.'
    },
    {
      icon: TrendingUp,
      title: 'Innovation',
      description: 'Embracing technology and modern practices to enhance customer experience and streamline processes.'
    }
  ];

  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Shri RK Homes",
    "description": "Mission and vision of Shri RK Homes - transforming real estate consulting with transparency, quality, and customer-first approach.",
    "url": "https://shrirkhomes.com/mission-vision"
  };

  return (
    <>
      <Helmet>
        <title>Mission & Vision - Shri RK Homes | Our Commitment to Excellence</title>
        <meta name="description" content="Discover the mission, vision, and core values of Shri RK Homes. Learn about our commitment to transparent real estate transactions, RERA compliance, and customer satisfaction in Noida, Greater Noida, and Yamuna Expressway." />
        <meta name="keywords" content="Shri RK Homes mission, real estate vision, core values, company milestones, commitment to excellence, transparent real estate, RERA compliance" />
        <link rel="canonical" href="https://shrirkhomes.com/mission-vision" />
        
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>

      <Header />

      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'Mission & Vision' }]} />
      </div>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-[#9c4915]/10 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Mission & Vision</h1>
            <p className="text-xl text-muted-foreground">
              Guiding principles that drive our commitment to excellence in real estate consulting
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-[#9c4915]/10 rounded-full flex items-center justify-center">
                  <Target className="w-8 h-8 text-[#9c4915]" />
                </div>
                <h2 className="text-3xl font-bold">Our Mission</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed">
                To empower every individual and family in their real estate journey by providing transparent, reliable, and customer-centric property solutions. We are committed to making property buying a joyful and stress-free experience through RERA compliance, complete documentation support, and personalized guidance at every step.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <Card className="bg-gradient-to-br from-[#9c4915] to-[#7a3710] text-white">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-4">What Drives Us</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3">
                      <span className="text-2xl">✓</span>
                      <span>Making real estate transactions transparent and trustworthy</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-2xl">✓</span>
                      <span>Ensuring 100% RERA compliance for buyer protection</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-2xl">✓</span>
                      <span>Providing end-to-end support from search to possession</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-2xl">✓</span>
                      <span>Building long-term relationships based on trust</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Vision Statement */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-2 md:order-1"
            >
              <Card className="bg-gradient-to-br from-blue-600 to-blue-700 text-white">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-4">Our Vision for the Future</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3">
                      <span className="text-2xl">→</span>
                      <span>Become the most trusted real estate brand in NCR</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-2xl">→</span>
                      <span>Set new standards for transparency in the industry</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-2xl">→</span>
                      <span>Leverage technology for enhanced customer experience</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-2xl">→</span>
                      <span>Expand services across major Indian cities</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-1 md:order-2"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                  <Eye className="w-8 h-8 text-blue-600" />
                </div>
                <h2 className="text-3xl font-bold">Our Vision</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed">
                To be recognized as India's most trusted and innovative real estate consulting firm, setting industry benchmarks for transparency, customer service, and ethical practices. We envision a future where every property transaction is seamless, secure, and satisfying for all stakeholders.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Core Values Detailed */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Core Values That Define Us</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              The fundamental principles that guide our decisions and actions every day
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {coreValues.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-[#9c4915]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Icon className="w-6 h-6 text-[#9c4915]" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                          <p className="text-muted-foreground">{value.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Milestones Timeline */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Journey of Excellence</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Key milestones that mark our growth and commitment to serving clients
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            <div className="relative">
              {/* Timeline Line */}
              <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-[#9c4915]/20" />

              {milestones.map((milestone, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative flex items-center mb-8 ${
                    index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}
                >
                  <div className={`w-full md:w-1/2 ${index % 2 === 0 ? 'md:pr-12' : 'md:pl-12'}`}>
                    <Card className="hover:shadow-lg transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="text-2xl font-bold text-[#9c4915]">{milestone.year}</span>
                        </div>
                        <h3 className="text-xl font-bold mb-2">{milestone.title}</h3>
                        <p className="text-muted-foreground">{milestone.description}</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Timeline Dot */}
                  <div className="absolute left-8 md:left-1/2 w-4 h-4 bg-[#9c4915] rounded-full border-4 border-white transform -translate-x-1/2" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Detailed Content */}
      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <article className="prose prose-lg max-w-none">
            <h2 className="text-3xl font-bold mb-6">Commitment to Excellence in Real Estate</h2>
            
            <p className="text-gray-700 mb-6">
              At Shri RK Homes, our mission and vision are not just words on paper—they are the foundation of everything we do. Every decision, every interaction, and every service we provide is guided by our commitment to transparency, quality, and customer satisfaction. We believe that real estate is not just about buying and selling properties; it's about helping people achieve their dreams of homeownership and financial security.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Transparency as Our Foundation</h3>
            <p className="text-gray-700 mb-6">
              Transparency is the cornerstone of trust in real estate. We ensure complete disclosure of property details, pricing structures, payment plans, and legal documentation. Our clients receive detailed property reports, RERA registration certificates, approved building plans, and clear timelines before making any commitment. We believe that informed clients make better decisions, and we empower them with all the information they need.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Quality Without Compromise</h3>
            <p className="text-gray-700 mb-6">
              Quality is non-negotiable at Shri RK Homes. We partner only with RERA registered builders who have proven track records of timely delivery and quality construction. Every property in our portfolio undergoes rigorous verification—we check construction quality, amenities, location advantages, legal clearances, and builder reputation before recommending it to our clients. This meticulous approach ensures that our clients invest in properties that offer genuine value and long-term appreciation.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Customer-First Philosophy</h3>
            <p className="text-gray-700 mb-6">
              Our customers are at the heart of everything we do. We understand that buying property is one of the most significant financial decisions in a person's life, and we treat every client's needs with the utmost care and attention. Our team takes time to understand individual requirements, budget constraints, and lifestyle preferences. We provide personalized property recommendations, arrange site visits at convenient times, and offer flexible consultation hours to accommodate busy schedules.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Innovation and Technology Integration</h3>
            <p className="text-gray-700 mb-6">
              In an era of digital transformation, we leverage technology to enhance customer experience. Our website features advanced search filters, virtual property tours, EMI calculators, and property comparison tools. Clients can track their transaction status online, receive instant property alerts, and access market insights through our digital platforms. We also use data analytics to provide accurate property valuations and investment recommendations.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Building Long-Term Relationships</h3>
            <p className="text-gray-700 mb-6">
              We don't view our clients as one-time transactions. We build relationships that last a lifetime. Many of our clients return to us for their second and third property purchases, and they refer their friends and family to us. This loyalty is earned through consistent service quality, honest communication, and genuine care for their success. We provide post-purchase support, assist with property maintenance, and stay connected with our clients long after the deal is closed.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Social Responsibility and Community Impact</h3>
            <p className="text-gray-700 mb-6">
              As a responsible business, we recognize our role in the community. We actively participate in initiatives that promote affordable housing, educate first-time buyers about their rights, and support local development projects. We also contribute to environmental conservation by promoting green buildings and sustainable construction practices. Our vision extends beyond business success—we want to make a positive impact on society and the environment.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Looking Ahead: Our Future Goals</h3>
            <p className="text-gray-700 mb-6">
              As we look to the future, we are excited about the opportunities ahead. We plan to expand our services to more cities across India, introduce innovative property financing solutions, and continue setting new standards for transparency and customer service in the real estate industry. We are investing in technology, training our team, and building partnerships that will enable us to serve our clients even better.
            </p>

            <div className="bg-[#9c4915]/10 p-6 rounded-lg mt-8">
              <h3 className="text-2xl font-bold mb-4">Join Us in Our Mission</h3>
              <p className="text-gray-700">
                Whether you're a first-time homebuyer, an experienced investor, or someone looking to upgrade your living space, Shri RK Homes is here to support you. Experience the difference of working with a real estate consultant who truly cares about your success and is committed to making your property dreams a reality.
              </p>
            </div>
          </article>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default MissionVision;