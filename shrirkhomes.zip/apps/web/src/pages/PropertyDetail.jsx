import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Home, Maximize, DollarSign, Download, X, ChevronLeft, ChevronRight, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import { useToast } from '@/hooks/use-toast';

const PropertyDetail = () => {
  const { id } = useParams();
  const { toast } = useToast();
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const property = {
    id: 1,
    title: 'Luxury 3 BHK Apartment in Sector 137',
    location: 'Sector 137, Noida',
    type: 'High-Rise Apartment',
    price: '₹85 Lakhs',
    bhk: '3 BHK',
    area: '1450 sq.ft',
    status: 'Ready to Move',
    rera: 'UPRERAPRJ12345',
    images: [
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1600607687931-ceeb66d11362?auto=format&fit=crop&w=1000&q=80'
    ],
    highlights: [
      'Prime location with excellent connectivity',
      'Modern architecture and premium finishes',
      'Vastu compliant layout',
      'Ample natural light and ventilation',
      'Covered parking for 2 vehicles',
      'Power backup and water supply'
    ],
    amenities: [
      'Swimming Pool',
      'Gymnasium',
      'Clubhouse',
      'Children\'s Play Area',
      'Landscaped Gardens',
      '24/7 Security',
      'CCTV Surveillance',
      'Intercom Facility',
      'Lift',
      'Visitor Parking'
    ],
    description: 'Experience luxury living in this spacious 3 BHK apartment located in the heart of Noida Sector 137. This RERA approved property offers modern amenities, excellent connectivity, and a premium lifestyle. The apartment features a well-designed layout with ample natural light, premium fittings, and contemporary interiors.'
  };

  const faqs = [
    {
      question: 'Is this property RERA approved?',
      answer: 'Yes, this property is fully RERA approved with registration number UPRERAPRJ12345. All legal documentation is verified and available for review.'
    },
    {
      question: 'What is the possession timeline?',
      answer: 'This is a ready-to-move property. Immediate possession is available upon completion of documentation and payment.'
    },
    {
      question: 'Are home loans available for this property?',
      answer: 'Yes, we provide complete assistance with home loan processing. We have tie-ups with major banks and financial institutions offering competitive interest rates.'
    },
    {
      question: 'What are the maintenance charges?',
      answer: 'The monthly maintenance charges are approximately ₹3,500, which covers common area maintenance, security, and amenities upkeep.'
    },
    {
      question: 'Can I schedule a site visit?',
      answer: 'Absolutely! You can schedule a site visit by filling out the inquiry form or calling us directly. We arrange guided property tours at your convenience.'
    }
  ];

  const similarProperties = [
    {
      id: 2,
      title: 'Modern 3 BHK Flat',
      location: 'Sector 150, Noida',
      price: '₹78 Lakhs',
      image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80'
    },
    {
      id: 3,
      title: 'Spacious 4 BHK Apartment',
      location: 'Sector 168, Noida',
      price: '₹1.2 Cr',
      image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=80'
    }
  ];

  const handleInquirySubmit = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 Feature Coming Soon!",
      description: "Inquiry form submission will be available soon. You can request it in your next prompt! 🚀",
    });
  };

  const handleDownloadBrochure = () => {
    toast({
      title: "🚧 Feature Coming Soon!",
      description: "Brochure download will be available soon. You can request it in your next prompt! 🚀",
    });
  };

  const openLightbox = (index) => {
    setCurrentImageIndex(index);
    setLightboxOpen(true);
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % property.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
  };

  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "Product",
    "name": property.title,
    "description": property.description,
    "image": property.images,
    "offers": {
      "@type": "Offer",
      "price": property.price,
      "priceCurrency": "INR",
      "availability": "https://schema.org/InStock"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.8",
      "reviewCount": "24"
    }
  };

  return (
    <>
      <Helmet>
        <title>{`${property.title} | Shri RK Homes`}</title>
        <meta name="description" content={`${property.description} RERA approved property in ${property.location}. Contact Shri RK Homes for site visits and complete documentation support.`} />
        <meta name="keywords" content={`${property.bhk} apartment ${property.location}, RERA approved property, luxury apartment Noida, ${property.type}`} />
        <link rel="canonical" href={`https://shrirkhomes.com/property/${id}`} />
        
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>

      <Header />

      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[
          { label: 'Properties', href: '/properties' },
          { label: property.title }
        ]} />
      </div>

      {/* Image Gallery */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-4 max-w-6xl mx-auto">
            <div className="md:col-span-2">
              <div 
                className="relative h-96 rounded-lg overflow-hidden cursor-pointer"
                onClick={() => openLightbox(0)}
              >
                <img 
                  src={property.images[0]} 
                  alt={property.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-1 gap-4">
              {property.images.slice(1).map((image, index) => (
                <div 
                  key={index}
                  className="relative h-44 rounded-lg overflow-hidden cursor-pointer"
                  onClick={() => openLightbox(index + 1)}
                >
                  <img 
                    src={image} 
                    alt={`${property.title} - Image ${index + 2}`}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Property Details */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="lg:col-span-2">
              <Card>
                <CardContent className="p-8">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <span className="text-[#9c4915] font-semibold">{property.type}</span>
                      <h1 className="text-3xl font-bold mb-2">{property.title}</h1>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        <span>{property.location}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold text-[#9c4915]">{property.price}</p>
                      <p className="text-sm text-muted-foreground">₹5,862/sq.ft</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-8 p-4 bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <Home className="w-6 h-6 text-[#9c4915] mx-auto mb-2" />
                      <p className="font-semibold">{property.bhk}</p>
                      <p className="text-sm text-muted-foreground">Configuration</p>
                    </div>
                    <div className="text-center">
                      <Maximize className="w-6 h-6 text-[#9c4915] mx-auto mb-2" />
                      <p className="font-semibold">{property.area}</p>
                      <p className="text-sm text-muted-foreground">Carpet Area</p>
                    </div>
                    <div className="text-center">
                      <CheckCircle className="w-6 h-6 text-green-600 mx-auto mb-2" />
                      <p className="font-semibold">{property.status}</p>
                      <p className="text-sm text-muted-foreground">Status</p>
                    </div>
                  </div>

                  <div className="mb-8">
                    <h2 className="text-2xl font-bold mb-4">Property Highlights</h2>
                    <div className="grid md:grid-cols-2 gap-3">
                      {property.highlights.map((highlight, index) => (
                        <div key={index} className="flex items-start gap-2">
                          <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700">{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mb-8">
                    <h2 className="text-2xl font-bold mb-4">Description</h2>
                    <p className="text-gray-700 leading-relaxed">{property.description}</p>
                  </div>

                  <div className="mb-8">
                    <h2 className="text-2xl font-bold mb-4">Amenities</h2>
                    <div className="grid md:grid-cols-3 gap-3">
                      {property.amenities.map((amenity, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-[#9c4915]" />
                          <span className="text-gray-700">{amenity}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mb-8">
                    <h2 className="text-2xl font-bold mb-4">Location Map</h2>
                    <div className="bg-gray-200 h-64 rounded-lg flex items-center justify-center">
                      <p className="text-muted-foreground">Map will be embedded here</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button 
                      className="bg-[#9c4915] hover:bg-[#7a3710]"
                      onClick={handleDownloadBrochure}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download Brochure
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* FAQ Section */}
              <Card className="mt-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
                  <Accordion type="single" collapsible>
                    {faqs.map((faq, index) => (
                      <AccordionItem key={index} value={`item-${index}`}>
                        <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                        <AccordionContent className="text-gray-700">{faq.answer}</AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            </div>

            {/* Inquiry Form */}
            <div>
              <Card className="sticky top-24">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4">Interested in this property?</h3>
                  <form onSubmit={handleInquirySubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      <Input id="name" placeholder="Enter your name" className="text-gray-900" required />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" placeholder="your@email.com" className="text-gray-900" required />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" type="tel" placeholder="+91 XXXXX XXXXX" className="text-gray-900" required />
                    </div>
                    <div>
                      <Label htmlFor="message">Message</Label>
                      <Textarea id="message" placeholder="I'm interested in this property..." className="text-gray-900" rows={4} />
                    </div>
                    <Button type="submit" className="w-full bg-[#9c4915] hover:bg-[#7a3710]">
                      Send Inquiry
                    </Button>
                  </form>
                  <div className="mt-6 pt-6 border-t">
                    <p className="text-sm text-muted-foreground mb-2">RERA Registration</p>
                    <p className="font-semibold">{property.rera}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Similar Properties */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Similar Properties</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {similarProperties.map((prop) => (
              <Card key={prop.id} className="overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative h-48">
                  <img 
                    src={prop.image} 
                    alt={prop.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-2">{prop.title}</h3>
                  <p className="text-muted-foreground mb-2">{prop.location}</p>
                  <p className="text-2xl font-bold text-[#9c4915] mb-4">{prop.price}</p>
                  <Link to={`/property/${prop.id}`}>
                    <Button variant="outline" className="w-full border-[#9c4915] text-[#9c4915] hover:bg-[#9c4915] hover:text-white">
                      View Details
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {lightboxOpen && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <button
            onClick={() => setLightboxOpen(false)}
            className="absolute top-4 right-4 text-white hover:text-gray-300"
            aria-label="Close lightbox"
          >
            <X className="w-8 h-8" />
          </button>
          <button
            onClick={prevImage}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-white hover:text-gray-300"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-12 h-12" />
          </button>
          <button
            onClick={nextImage}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-white hover:text-gray-300"
            aria-label="Next image"
          >
            <ChevronRight className="w-12 h-12" />
          </button>
          <img 
            src={property.images[currentImageIndex]} 
            alt={`${property.title} - Image ${currentImageIndex + 1}`}
            className="max-w-full max-h-full object-contain"
          />
        </div>
      )}

      <Footer />
    </>
  );
};

export default PropertyDetail;