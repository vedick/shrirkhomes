import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Calendar, User, ArrowRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';

const Blog = () => {
  const posts = [
    {
      id: 1,
      title: 'Why Noida is the Best Real Estate Investment Destination in 2024',
      excerpt: 'Discover the key infrastructure developments and market trends making Noida a hotspot for property investors.',
      date: 'Oct 15, 2023',
      author: 'RK Homes Expert',
      image: 'https://images.unsplash.com/photo-1582407947304-fd86f028f716?auto=format&fit=crop&w=1000&q=80'
    },
    {
      id: 2,
      title: 'Understanding RERA: A Complete Guide for Homebuyers',
      excerpt: 'Learn how the Real Estate Regulatory Authority protects your rights and ensures transparent property transactions.',
      date: 'Nov 02, 2023',
      author: 'Legal Team',
      image: 'https://images.unsplash.com/photo-1554469384-e58fac16e23a?auto=format&fit=crop&w=1000&q=80'
    },
    {
      id: 3,
      title: 'High-Rise vs Builder Floor: Which is Right for You?',
      excerpt: 'A detailed comparison of living in a high-rise apartment versus an independent builder floor in Greater Noida.',
      date: 'Nov 20, 2023',
      author: 'Property Advisor',
      image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=1000&q=80'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Real Estate Blog & Insights | Shri RK Homes</title>
        <meta name="description" content="Read the latest real estate news, investment tips, and property market insights for Noida, Greater Noida, and Yamuna Expressway." />
      </Helmet>
      <Header />
      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'Blog' }]} />
        
        <div className="py-12">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h1 className="text-4xl font-bold mb-4">Real Estate Insights</h1>
            <p className="text-xl text-muted-foreground">
              Expert advice, market trends, and property investment guides
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {posts.map((post) => (
              <Card key={post.id} className="overflow-hidden hover:shadow-xl transition-shadow">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {post.date}
                    </div>
                    <div className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      {post.author}
                    </div>
                  </div>
                  <h2 className="text-xl font-bold mb-3 line-clamp-2">{post.title}</h2>
                  <p className="text-gray-600 mb-4 line-clamp-3">{post.excerpt}</p>
                  <Button variant="link" className="text-[#9c4915] p-0 h-auto font-semibold hover:text-[#7a3710]">
                    Read More <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Blog;