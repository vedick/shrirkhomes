import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Shri RK Homes</title>
        <meta name="description" content="Privacy Policy for Shri RK Homes. Learn how we protect your data and personal information." />
      </Helmet>
      <Header />
      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'Privacy Policy' }]} />
        <div className="max-w-4xl mx-auto py-12">
          <h1 className="text-4xl font-bold mb-8">Privacy Policy</h1>
          <div className="prose prose-lg max-w-none text-gray-700">
            <p>Last updated: {new Date().toLocaleDateString()}</p>
            <p>At Shri RK Homes, we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.</p>
            <h2>Information We Collect</h2>
            <p>We may collect personal information such as your name, email address, phone number, and property preferences when you fill out contact forms or inquire about properties.</p>
            <h2>How We Use Your Information</h2>
            <p>We use the information we collect to provide personalized property recommendations, respond to your inquiries, arrange site visits, and send you relevant real estate updates.</p>
            <h2>Data Security</h2>
            <p>We implement appropriate security measures to protect your personal information from unauthorized access, alteration, disclosure, or destruction.</p>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Privacy;