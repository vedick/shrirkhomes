import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Award, Target, TrendingUp, Shield, BookOpen, Briefcase, Heart, Globe } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import { Card, CardContent } from '@/components/ui/card';
const FoundersCut = () => {
  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    "mainEntity": {
      "@type": "Person",
      "name": "Mr. Amit Barthwal",
      "jobTitle": "Founder & CEO",
      "worksFor": {
        "@type": "Organization",
        "name": "Shri RK Homes"
      },
      "alumniOf": "MBA",
      "description": "Founder of Shri RK Homes, a RERA authorized real estate consultancy in Noida."
    }
  };
  const sections = [{
    id: "vision",
    icon: Target,
    title: "Vision for the Future",
    content: "At Shri RK Homes, our vision extends far beyond mere property transactions. We envision a real estate ecosystem where trust, transparency, and customer empowerment are the foundational pillars. Mr. Amit Barthwal's foresight is to transform the Noida and Greater Noida real estate landscape into a globally recognized hub for premium, sustainable, and community-centric living. We aim to be the catalyst that bridges the gap between aspirational living and accessible real estate, ensuring that every family finds not just a house, but a home that resonates with their dreams and values. Our long-term vision involves integrating advanced prop-tech solutions to make property discovery and acquisition a seamless, joyous journey for every client."
  }, {
    id: "mission",
    icon: Award,
    title: "Our Core Mission",
    content: "Our mission is deeply rooted in an unwavering commitment to quality, transparency, and absolute customer satisfaction. We strive to demystify the complex world of real estate for our clients, providing them with clear, actionable, and honest insights. Under Mr. Barthwal's leadership, Shri RK Homes is dedicated to curating a portfolio of exclusively RERA-approved projects, ensuring that our clients' investments are secure and legally sound. We are on a mission to elevate the standard of real estate consultancy by offering personalized, end-to-end services that cover everything from initial property discovery to post-possession support, fostering lifelong relationships built on mutual respect and proven results."
  }, {
    id: "expertise",
    icon: TrendingUp,
    title: "Industry Expertise",
    content: "With a profound understanding of market dynamics, investment strategies, and property development, Mr. Amit Barthwal brings a wealth of expertise to the table. His analytical approach to real estate investment ensures that clients are guided towards properties that offer not just immediate utility but substantial long-term appreciation. His expertise spans across luxury high-rise apartments, premium builder floors, and high-yield commercial spaces along the Yamuna Expressway. By continuously monitoring market trends, infrastructural developments, and regulatory changes, he ensures that Shri RK Homes remains ahead of the curve, offering strategic advice that maximizes ROI and minimizes risk for both individual homebuyers and institutional investors."
  }, {
    id: "experience",
    icon: Briefcase,
    title: "Track Record & Experience",
    content: "Years of dedicated service in the highly competitive NCR real estate market have equipped Mr. Barthwal with an unparalleled depth of experience. His track record is defined by hundreds of successful transactions, satisfied families, and thriving commercial investments. He has successfully navigated the market through various economic cycles, demonstrating resilience and strategic acumen. His experience is not just in selling properties, but in understanding the nuanced needs of diverse client profiles—from first-time homebuyers seeking affordable luxury to seasoned investors looking for portfolio diversification. This extensive experience translates into a smooth, hassle-free experience for every client who walks through the doors of Shri RK Homes."
  }, {
    id: "qualifications",
    icon: BookOpen,
    title: "Professional Qualifications",
    content: "Mr. Amit Barthwal's professional journey is backed by robust academic and professional credentials. Holding a Master of Business Administration (MBA) degree, he applies rigorous business principles, financial modeling, and strategic management to the real estate sector. Furthermore, his status as a RERA Authorized consultant is a testament to his commitment to legal compliance and ethical practices. These qualifications ensure that the advice provided by Shri RK Homes is not only market-savvy but also structurally sound and legally vetted. His continuous pursuit of professional development keeps the agency aligned with the latest industry standards and best practices."
  }, {
    id: "values",
    icon: Heart,
    title: "Core Values & Ethics",
    content: "The foundation of Shri RK Homes is built on a bedrock of uncompromising ethics and core values. Mr. Barthwal champions a culture of absolute integrity, where honest communication takes precedence over quick sales. We believe in sustainable community development, advocating for projects that respect the environment and enhance the quality of life for residents. Empathy is at the heart of our operations; we understand that buying a property is often the most significant financial decision in a person's life, and we treat it with the gravity and respect it deserves. Our values dictate that we act as fiduciaries for our clients, always placing their interests above our own."
  }, {
    id: "future",
    icon: Globe,
    title: "Future Goals & Expansion",
    content: "Looking ahead, Mr. Amit Barthwal's goals for Shri RK Homes involve strategic expansion and continuous innovation. We plan to broaden our footprint across emerging micro-markets in the NCR region, identifying the next big investment hotspots before they become mainstream. Innovation in customer service, through the adoption of virtual reality tours, AI-driven property matching, and blockchain-based transparent documentation, is high on our agenda. Ultimately, the goal is to establish Shri RK Homes not just as a regional leader, but as a national benchmark for excellence in real estate consultancy, setting new standards for how properties are bought, sold, and managed in India."
  }];
  return <>
      <Helmet>
        <title>Founder's Cut - Mr. Amit Barthwal | Shri RK Homes</title>
        <meta name="description" content="Read the comprehensive biography of Mr. Amit Barthwal, MBA and RERA Authorized Founder of Shri RK Homes. Discover his vision, mission, and expertise in Noida real estate." />
        <meta name="keywords" content="Amit Barthwal, Shri RK Homes founder, Noida real estate developer, RERA authorized consultant, property investment expert NCR" />
        <link rel="canonical" href="https://shrirkhomes.com/founders-cut" />
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>

      <Header />

      {/* Hero Section */}
      <section className="relative h-[60vh] min-h-[500px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img src="https://images.unsplash.com/photo-1697638164340-6c5fc558bdf2?auto=format&fit=crop&w=1920&q=80" alt="Professional office environment" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/80 backdrop-blur-[2px]" />
        </div>
        
        <div className="relative container mx-auto px-4 text-center z-10">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8
        }}>
            <h1 className="text-8xl md:text-8xl font-bold text-white mb-6 tracking-tight">
              The Founder's Cut
            </h1>
            <p className="text-xl md:text-2xl text-white max-w-3xl mx-auto font-regular">
              Leadership, Vision, and the Drive to Transform Real Estate
            </p>
          </motion.div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-6">
        <Breadcrumb items={[{
        label: "Founder's Cut"
      }]} />
      </div>

      {/* Profile Introduction Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex flex-col lg:flex-row gap-12 items-center">
            <motion.div initial={{
            opacity: 0,
            x: -50
          }} whileInView={{
            opacity: 1,
            x: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6
          }} className="w-full lg:w-1/3">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white">
                <img src="https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/founder-bgr-FrcJx.png" alt="Mr. Amit Barthwal - Founder of Shri RK Homes" className="w-full h-auto object-cover aspect-[3/4]" />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 text-center">
                  <h2 className="text-2xl font-bold text-white">Mr. Amit Barthwal</h2>
                  <p className="text-[#e67e22] font-medium">MBA, RERA Authorized</p>
                <p className="text-gray-300 text-sm">Founder & CEO, Shri RK Homes</p>
                <p className="text-[#e67e22] font-bold">RERA NO - UPRERAAGT000285</p>  
                </div>
              </div>
            </motion.div>

            <motion.div initial={{
            opacity: 0,
            x: 50
          }} whileInView={{
            opacity: 1,
            x: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6
          }} className="w-full lg:w-2/3 space-y-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#9c4915]/10 text-[#9c4915] font-semibold text-sm mb-2">
                <Shield className="w-4 h-4" />
                RERA Authorized Consultant
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 leading-tight">
                Redefining Trust in Noida's Real Estate Landscape
              </h2>
              <div className="prose prose-lg text-light black max-w-none">
                <p>
                  Welcome to Shri RK Homes. I am Amit Barthwal, and my journey in the real estate sector has been driven by a singular, unwavering passion: to bring absolute transparency, professionalism, and customer-centricity to property investments in the National Capital Region.
                </p>
                <p>
                  Armed with a Master of Business Administration (MBA) and officially recognized as a RERA Authorized consultant, I founded Shri RK Homes to serve as a beacon of reliability in an industry often clouded by complexity. My academic background provides the analytical rigor needed to assess market trends and investment viability, while my RERA authorization ensures that every transaction we facilitate adheres to the highest standards of legal and ethical compliance.
                </p>
                <p>
                  We don't just sell properties; we curate lifestyles and secure financial futures. Whether you are looking for a luxury high-rise in Noida, a spacious builder floor in Greater Noida, or a lucrative commercial space on the Yamuna Expressway, my team and I are dedicated to guiding you through every step of the process with integrity and expertise.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Detailed Biography Sections */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">The Philosophy Behind the Success</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Explore the core principles, extensive experience, and forward-looking vision that drive Mr. Amit Barthwal and Shri RK Homes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {sections.map((section, index) => {
            const Icon = section.icon;
            return <motion.div key={section.id} initial={{
              opacity: 0,
              y: 30
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5,
              delay: index * 0.1
            }}>
                  <Card className="h-full rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 border-t-4 border-t-transparent hover:border-t-[#9c4915] bg-white">
                    <CardContent className="p-8">
                      <div className="w-14 h-14 bg-[#9c4915]/10 rounded-xl flex items-center justify-center mb-6">
                        <Icon className="w-7 h-7 text-[#9c4915]" />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-4">{section.title}</h3>
                      <p className="text-gray-600 leading-relaxed">
                        {section.content}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>;
          })}
          </div>
        </div>
      </section>

      {/* Closing Statement */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <motion.div initial={{
          opacity: 0,
          scale: 0.95
        }} whileInView={{
          opacity: 1,
          scale: 1
        }} viewport={{
          once: true
        }} className="bg-gradient-to-br from-[#9c4915] to-[#7a3710] rounded-3xl p-10 md:p-16 text-white shadow-2xl">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">"Together, Towards a Better Tomorrow"</h2>
            <p className="text-lg md:text-xl font-light leading-relaxed mb-8 opacity-90">
              "Real estate is more than bricks and mortar; it is the foundation upon which families build their futures and investors secure their legacies. At Shri RK Homes, we are honored to be the architects of those dreams. I invite you to experience a new standard of real estate consultancy—one where your aspirations are our blueprint."
            </p>
          <div className="text-center">
            <div className="flex items-center justify-center gap-4">
              <div className="h-[1px] w-12 bg-white/50" />
              <p className="font-bold text-lg tracking-wider">AMIT BARTHWAL</p>
              <div className="h-[1px] w-12 bg-white/50" />
            </div>

            <p className="mt-0 text-lg font-semibold tracking-widest text-white/90 uppercase">
              CEO & Founder
            </p>

            <p className="text-semibold text-white font-bold mt-1">
              RERA NO - UPRERAAGT000285
            </p>
          </div>

          </motion.div>
        </div>
    </section>

      <Footer />
    </>;
};
export default FoundersCut;