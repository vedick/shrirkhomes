import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Terms & Conditions | Shri RK Homes</title>
        <meta name="description" content="Terms and Conditions for using Shri RK Homes website and services." />
      </Helmet>
      <Header />
      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'Terms & Conditions' }]} />
        <div className="max-w-4xl mx-auto py-12">
          <h1 className="text-4xl font-bold mb-8">Terms & Conditions</h1>
          <div className="prose prose-lg max-w-none text-gray-700">
            <p>Last updated: {new Date().toLocaleDateString()}</p>
            <h2>Agreement to Terms</h2>
            <p>By accessing or using the Shri RK Homes website, you agree to be bound by these Terms and Conditions and our Privacy Policy.</p>
            <h2>Property Information</h2>
            <p>While we strive to provide accurate property information, prices, availability, and specifications are subject to change without notice. All property details should be verified independently before making any financial commitment.</p>
            <h2>RERA Compliance</h2>
            <p>We deal exclusively in RERA registered properties. However, buyers are advised to verify the RERA registration details and project status on the official UP RERA website.</p>
            <h2>Limitation of Liability</h2>
            <p>Shri RK Homes shall not be liable for any direct, indirect, incidental, or consequential damages resulting from the use or inability to use our services or website.</p>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Terms;