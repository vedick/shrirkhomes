import React, { useState, useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion, useInView, animate } from 'framer-motion';
import { Building2, Home, Store, Shield, ChevronLeft, ChevronRight, Star, Phone, Calendar, Gift, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ContactFormModal from '@/components/ContactFormModal.jsx';
import SiteVisitModal from '@/components/SiteVisitModal.jsx';
import OffersModal from '@/components/OffersModal.jsx';
import BrandPartnersSlideshow from '@/components/BrandPartnersSlideshow.jsx';
const CounterItem = ({
  end,
  label,
  suffix = "+"
}) => {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const inView = useInView(ref, {
    once: true,
    margin: "-100px"
  });
  useEffect(() => {
    if (inView) {
      const controls = animate(0, end, {
        duration: 2,
        ease: "easeOut",
        onUpdate: value => setCount(Math.floor(value))
      });
      return controls.stop;
    }
  }, [inView, end]);
  return <Card ref={ref} className="bg-white border border-gray-100 hover:scale-105 transition-transform duration-300 shadow-sm hover:shadow-md">
      <CardContent className="p-6 text-center">
        <h3 className="text-4xl font-bold text-[#9c4915] mb-2">
          {count}{suffix}
        </h3>
        <p className="text-gray-600 font-medium">{label}</p>
      </CardContent>
    </Card>;
};
const HomePage = () => {
  const [currentProjectIndex, setCurrentProjectIndex] = useState(0);
  const [currentTestimonialIndex, setCurrentTestimonialIndex] = useState(0);

  // Modal States
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isSiteVisitModalOpen, setIsSiteVisitModalOpen] = useState(false);
  const [isOffersModalOpen, setIsOffersModalOpen] = useState(false);
  const featuredProjects = [{
    id: 1,
    title: 'Luxury High-Rise Apartments',
    location: 'Sector 137, Noida',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1000&q=80',
    type: 'High-Rise',
    status: 'Ready to Move',
    rera: 'RERA Approved'
  }, {
    id: 2,
    title: 'Premium Builder Floors',
    location: 'Greater Noida West',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=80',
    type: 'Builder Floor',
    status: 'Under Construction',
    rera: 'RERA Approved'
  }, {
    id: 3,
    title: 'Commercial Complex',
    location: 'Yamuna Expressway',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1000&q=80',
    type: 'Commercial',
    status: 'New Launch',
    rera: 'RERA Approved'
  }];
  const services = [{
    icon: Building2,
    title: 'High-Rise Projects',
    description: 'Luxury apartments with modern amenities, 24/7 security, and prime locations in Noida and Greater Noida.',
    link: '/services#high-rise'
  }, {
    icon: Home,
    title: 'Builder Floors',
    description: 'Freehold properties with customizable designs, independent living spaces in premium localities.',
    link: '/services#builder-floors'
  }, {
    icon: Store,
    title: 'Commercial Properties',
    description: 'Office spaces and retail properties on Yamuna Expressway with high ROI potential.',
    link: '/services#commercial'
  }, {
    icon: Shield,
    title: 'RERA Guidance',
    description: 'Complete support for RERA approved projects, documentation, and transparent processes.',
    link: '/services#rera'
  }];
  const testimonials = [{
    name: 'Rajesh Kumar',
    location: 'Noida Sector 137',
    rating: 5,
    text: 'Shri RK Homes helped me find my dream apartment. Their transparency and RERA guidance made the entire process smooth and hassle-free.',
    property: '3 BHK High-Rise Apartment'
  }, {
    name: 'Priya Sharma',
    location: 'Greater Noida',
    rating: 5,
    text: 'Excellent service! The team was professional and helped me understand every detail. I highly recommend Shri RK Homes for builder floors.',
    property: '4 BHK Builder Floor'
  }, {
    name: 'Amit Verma',
    location: 'Yamuna Expressway',
    rating: 5,
    text: 'Best real estate consultant in Noida! They provided complete documentation support and site visit arrangements. Very satisfied with my commercial property investment.',
    property: 'Commercial Office Space'
  }];
  useEffect(() => {
    const projectInterval = setInterval(() => {
      setCurrentProjectIndex(prev => (prev + 1) % featuredProjects.length);
    }, 5000);
    const testimonialInterval = setInterval(() => {
      setCurrentTestimonialIndex(prev => (prev + 1) % testimonials.length);
    }, 6000);
    return () => {
      clearInterval(projectInterval);
      clearInterval(testimonialInterval);
    };
  }, []);
  const schemaMarkup = {
    "@context": "https://schema.org",
    "@graph": [{
      "@type": "Organization",
      "name": "Shri RK Homes",
      "url": "https://shrirkhomes.com",
      "logo": "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a5646/89b66dbe668adcc56bbba4265b131993.jpg",
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+91-7303459116",
        "contactType": "sales",
        "areaServed": ["IN"],
        "availableLanguage": ["en", "hi"]
      },
      "sameAs": ["https://facebook.com/shrirkhomes", "https://linkedin.com/company/shrirkhomes", "https://instagram.com/shrirkhomes"]
    }, {
      "@type": "LocalBusiness",
      "name": "Shri RK Homes",
      "image": "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a5646/89b66dbe668adcc56bbba4265b131993.jpg",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Noida",
        "addressRegion": "UP",
        "addressCountry": "IN"
      },
      "telephone": "+91-7303459116",
      "priceRange": "₹₹₹",
      "openingHours": "Mo-Su 09:00-20:00"
    }, {
      "@type": "WebSite",
      "name": "Shri RK Homes",
      "url": "https://shrirkhomes.com",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://shrirkhomes.com/properties?search={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    }]
  };
  return <>
      <Helmet>
        <title>Shri RK Homes - TOGETHER, TOWARDS A BETTER TOMORROW | RERA Approved Projects</title>
        <meta name="description" content="Shri RK Homes offers premium RERA approved real estate projects in Noida, Greater Noida, and Yamuna Expressway. Find luxury high-rise apartments, builder floors, and commercial properties with transparent processes and complete documentation support." />
        <meta name="keywords" content="RERA approved projects Noida, builder floors Greater Noida, commercial property Yamuna Expressway, luxury apartments Noida, real estate consultant Noida, premium properties Greater Noida, high-rise apartments Noida, freehold builder floors, office space Yamuna Expressway" />
        <link rel="canonical" href="https://shrirkhomes.com/" />
        
        {/* Open Graph Tags */}
        <meta property="og:title" content="Shri RK Homes - Premium Real Estate in Noida" />
        <meta property="og:description" content="Your trusted partner for RERA approved properties in Noida, Greater Noida, and Yamuna Expressway. Luxury apartments, builder floors, and commercial spaces." />
        <meta property="og:image" content="https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1000&q=80" />
        <meta property="og:url" content="https://shrirkhomes.com/" />
        <meta property="og:type" content="website" />
        
        {/* Twitter Card Tags */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Shri RK Homes - Premium Real Estate in Noida" />
        <meta name="twitter:description" content="RERA approved properties in Noida, Greater Noida, and Yamuna Expressway" />
        <meta name="twitter:image" content="https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1000&q=80" />
        
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>

      <Header />

      {/* Hero Section */}
      <section className="relative h-[600px] md:h-[700px] overflow-hidden">
        <div className="absolute inset-0">
          <img src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1920&q=80" alt="Luxury residential building with modern architecture in Noida" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 to-black/40" />
        </div>
        
        <div className="relative container mx-auto px-4 h-full flex items-center">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8
        }} className="max-w-2xl text-white">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              SHRI RK HOMES TOGETHER, TOWARDS A BETTER TOMORROW
            </h1>
            <p className="text-lg md:text-xl mb-8 text-gray-200">
              Discover RERA approved luxury apartments, builder floors, and commercial properties in Noida, Greater Noida, and Yamuna Expressway. Your trusted partner for transparent real estate transactions.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/properties">
                <Button size="lg" className="bg-[#9c4915] hover:bg-[#7a3710] text-white">
                  Explore Properties
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="bg-white/10 backdrop-blur-sm border-white text-white hover:bg-white hover:text-[#9c4915]" onClick={() => setIsSiteVisitModalOpen(true)}>
                <Calendar className="mr-2 w-5 h-5" />
                Schedule Site Visit
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Animated Numbers Counter Section */}
      <section className="py-12 bg-gray-50 border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            <CounterItem end={45} label="Total Projects" />
            <CounterItem end={1200} label="Happy Clients" />
            <CounterItem end={850} label="Properties Sold" />
            <CounterItem end={15} label="Years of Experience" />
          </div>
        </div>
      </section>

      {/* Brand Partners Slideshow */}
      <BrandPartnersSlideshow />

      {/* Featured Projects Carousel */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} className="text-center mb-12">
            <h2 className="text-4xl md:text-6xl font-bold mb-4">Featured RERA Approved Projects</h2>
            <p className="text-lg text-black-foreground max-w-2xl mx-auto">
              Explore our handpicked selection of premium properties across Noida, Greater Noida, and Yamuna Expressway
            </p>
          </motion.div>

          <div className="relative max-w-5xl mx-auto">
            <div className="overflow-hidden rounded-xl">
              <motion.div key={currentProjectIndex} initial={{
              opacity: 0,
              x: 100
            }} animate={{
              opacity: 1,
              x: 0
            }} exit={{
              opacity: 0,
              x: -100
            }} transition={{
              duration: 0.5
            }}>
                <Card className="border border-gray-100 shadow-xl">
                  <div className="grid md:grid-cols-2 gap-0">
                    <div className="relative h-64 md:h-auto">
                      <img src={featuredProjects[currentProjectIndex].image} alt={featuredProjects[currentProjectIndex].title} className="w-full h-full object-cover" />
                      <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold shadow-md">
                        {featuredProjects[currentProjectIndex].rera}
                      </div>
                    </div>
                    <CardContent className="p-8 flex flex-col justify-center bg-white">
                      <span className="text-[#9c4915] font-semibold mb-2">{featuredProjects[currentProjectIndex].type}</span>
                      <h3 className="text-2xl font-bold mb-3">{featuredProjects[currentProjectIndex].title}</h3>
                      <p className="text-light black-foreground mb-4">{featuredProjects[currentProjectIndex].location}</p>
                      <div className="flex items-center gap-2 mb-6">
                        <span className="px-3 py-1 bg-blue-50 text-blue-700 border border-blue-100 rounded-full text-sm font-medium">
                          {featuredProjects[currentProjectIndex].status}
                        </span>
                      </div>
                      <Link to={`/projects`}>
                        <Button className="bg-[#9c4915] hover:bg-[#7a3710]">
                          View Details
                          <ArrowRight className="ml-2 w-4 h-4" />
                        </Button>
                      </Link>
                    </CardContent>
                  </div>
                </Card>
              </motion.div>
            </div>

            {/* Carousel Controls */}
            <button onClick={() => setCurrentProjectIndex(prev => (prev - 1 + featuredProjects.length) % featuredProjects.length)} className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-3 rounded-full shadow-lg transition-all" aria-label="Previous project">
              <ChevronLeft className="w-6 h-6 text-[#9c4915]" />
            </button>
            <button onClick={() => setCurrentProjectIndex(prev => (prev + 1) % featuredProjects.length)} className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-3 rounded-full shadow-lg transition-all" aria-label="Next project">
              <ChevronRight className="w-6 h-6 text-[#9c4915]" />
            </button>

            {/* Dots Indicator */}
            <div className="flex justify-center gap-2 mt-6">
              {featuredProjects.map((_, index) => <button key={index} onClick={() => setCurrentProjectIndex(index)} className={`w-3 h-3 rounded-full transition-all ${index === currentProjectIndex ? 'bg-[#9c4915] w-8' : 'bg-gray-300'}`} aria-label={`Go to project ${index + 1}`} />)}
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Premium Services</h2>
            <p className="text-lg text-light black-foreground max-w-2xl mx-auto">
              Comprehensive real estate solutions tailored to your needs with complete RERA compliance and transparent processes
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => {
            const Icon = service.icon;
            return <motion.div key={index} initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              delay: index * 0.1
            }}>
                  <Card className="h-full hover:shadow-xl transition-shadow duration-300 border-t-4 border-t-[#9c4915]">
                    <CardContent className="p-6">
                      <div className="w-14 h-14 bg-[#9c4915]/10 rounded-lg flex items-center justify-center mb-4">
                        <Icon className="w-7 h-7 text-[#9c4915]" />
                      </div>
                      <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                      <p className="text-light black-foreground mb-4">{service.description}</p>
                      <Link to={service.link} className="text-[#9c4915] font-semibold hover:underline inline-flex items-center">
                        Learn More
                        <ArrowRight className="ml-1 w-4 h-4" />
                      </Link>
                    </CardContent>
                  </Card>
                </motion.div>;
          })}
          </div>
        </div>
      </section>

      {/* Testimonials Slider */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-lg text-light black-foreground max-w-2xl mx-auto">
              Real experiences from satisfied homeowners and investors across Noida and Greater Noida
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            <motion.div key={currentTestimonialIndex} initial={{
            opacity: 0,
            scale: 0.95
          }} animate={{
            opacity: 1,
            scale: 1
          }} transition={{
            duration: 0.5
          }}>
              <Card className="border border-gray-100 shadow-xl bg-gray-50">
                <CardContent className="p-8 md:p-12 text-center">
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonials[currentTestimonialIndex].rating)].map((_, i) => <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />)}
                  </div>
                  <p className="text-lg md:text-xl text-gray-700 mb-6 italic">
                    "{testimonials[currentTestimonialIndex].text}"
                  </p>
                  <div className="border-t border-gray-200 pt-6">
                    <p className="font-bold text-lg">{testimonials[currentTestimonialIndex].name}</p>
                    <p className="text-light black-foreground">{testimonials[currentTestimonialIndex].location}</p>
                    <p className="text-sm text-[#9c4915] mt-2 font-medium">{testimonials[currentTestimonialIndex].property}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Testimonial Dots */}
            <div className="flex justify-center gap-2 mt-6">
              {testimonials.map((_, index) => <button key={index} onClick={() => setCurrentTestimonialIndex(index)} className={`w-3 h-3 rounded-full transition-all ${index === currentTestimonialIndex ? 'bg-[#9c4915] w-8' : 'bg-gray-300'}`} aria-label={`Go to testimonial ${index + 1}`} />)}
            </div>
          </div>
        </div>
      </section>

      {/* Multiple CTA Sections */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-6">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }}>
              <Card className="bg-gradient-to-br from-[#9c4915] to-[#7a3710] text-white h-full border-none">
                <CardContent className="p-8 text-center">
                  <Phone className="w-12 h-12 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold mb-3">Enquire Now</h3>
                  <p className="mb-6 opacity-90">Get instant assistance from our property experts</p>
                  <Button variant="secondary" className="w-full text-[#9c4915] hover:bg-gray-100" onClick={() => setIsContactModalOpen(true)}>
                    Contact Us
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: 0.1
          }}>
              <Card className="bg-gradient-to-br from-blue-600 to-blue-800 text-white h-full border-none">
                <CardContent className="p-8 text-center">
                  <Calendar className="w-12 h-12 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold mb-3">Schedule Site Visit</h3>
                  <p className="mb-6 opacity-90">Visit properties with our guided tours</p>
                  <Button variant="secondary" className="w-full text-blue-700 hover:bg-gray-100" onClick={() => setIsSiteVisitModalOpen(true)}>
                    Book Visit
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: 0.2
          }}>
              <Card className="bg-gradient-to-br from-green-600 to-green-800 text-white h-full border-none">
                <CardContent className="p-8 text-center">
                  <Gift className="w-12 h-12 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold mb-3">Get Best Offer</h3>
                  <p className="mb-6 opacity-90">Exclusive deals and payment plans</p>
                  <Button variant="secondary" className="w-full text-green-700 hover:bg-gray-100" onClick={() => setIsOffersModalOpen(true)}>
                    View Offers
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* SEO Content Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <article className="prose prose-lg max-w-none">
            <h2 className="text-3xl font-bold mb-6">Why Choose Shri RK Homes for Your Real Estate Investment in Noida?</h2>
            
            <p className="text-gray-700 mb-6">
              Shri RK Homes stands as the premier real estate consultant in Noida, Greater Noida, and Yamuna Expressway, offering comprehensive property solutions backed by complete RERA compliance and transparent processes. With years of expertise in the NCR real estate market, we specialize in connecting discerning buyers with premium residential and commercial properties that match their investment goals and lifestyle aspirations.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">RERA Approved Projects in Noida - Your Guarantee of Trust</h3>
            <p className="text-gray-700 mb-6">
              All properties listed through Shri RK Homes are RERA registered, ensuring complete legal compliance and buyer protection. Our portfolio includes luxury high-rise apartments in Noida Sector 137, premium builder floors in Greater Noida West, and commercial properties along the Yamuna Expressway. Each project undergoes rigorous verification to guarantee authenticity, proper documentation, and adherence to construction timelines.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Comprehensive Property Solutions Across NCR</h3>
            <p className="text-gray-700 mb-6">
              Whether you're searching for ready-to-move luxury apartments, under-construction builder floors, or high-ROI commercial spaces, Shri RK Homes provides end-to-end assistance. Our services include property search based on your budget and preferences, site visit arrangements, documentation support, home loan guidance, and post-purchase assistance. We understand that buying property is a significant investment, and our team ensures every step is transparent and hassle-free.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Builder Floors in Greater Noida - Freehold Living at Its Best</h3>
            <p className="text-gray-700 mb-6">
              Our exclusive collection of builder floors in Greater Noida offers the perfect blend of independent living and modern amenities. These freehold properties provide complete ownership, customization options, and lower maintenance costs compared to high-rise apartments. Located in prime sectors with excellent connectivity to Delhi, Noida, and the upcoming Jewar Airport, these builder floors represent excellent value for money and long-term appreciation potential.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Commercial Property Investment on Yamuna Expressway</h3>
            <p className="text-gray-700 mb-6">
              The Yamuna Expressway corridor has emerged as a hotspot for commercial real estate investment, with world-class infrastructure, proximity to the Noida International Airport at Jewar, and excellent connectivity to Delhi-NCR. Shri RK Homes offers premium office spaces, retail properties, and mixed-use developments that promise high rental yields and capital appreciation. Our commercial property experts provide detailed market analysis, ROI projections, and investment guidance to help you make informed decisions.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Transparent Process and Complete Documentation Support</h3>
            <p className="text-gray-700 mb-6">
              At Shri RK Homes, transparency is our core value. We provide complete property documentation, including RERA registration certificates, approved building plans, NOCs, and title verification reports. Our legal team assists with property registration, stamp duty calculation, and home loan processing. We believe in building long-term relationships with our clients through honest communication and reliable service.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Expert Guidance for First-Time Homebuyers</h3>
            <p className="text-gray-700 mb-6">
              Buying your first home can be overwhelming, but Shri RK Homes makes it simple. Our property consultants provide personalized guidance on budget planning, location selection, amenity comparison, and financing options. We offer free property valuation, market trend analysis, and investment advice to ensure you make the right choice. Our EMI calculators, affordability tools, and stamp duty estimators help you plan your finances effectively.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Service Areas: Noida, Greater Noida, and Yamuna Expressway</h3>
            <p className="text-gray-700 mb-6">
              Shri RK Homes serves the entire NCR region with a special focus on Noida (Sectors 137, 150, 168), Greater Noida (Greater Noida West, Noida Extension, Techzone), and Yamuna Expressway (Sectors 16, 18, 22, 25). Our deep understanding of local market dynamics, infrastructure development, and future growth prospects enables us to recommend properties that offer the best value and appreciation potential.
            </p>

            <div className="bg-[#9c4915]/10 p-8 rounded-xl mt-8 border border-[#9c4915]/20">
              <h3 className="text-2xl font-bold mb-4 text-[#9c4915]">Ready to Find Your Dream Property?</h3>
              <p className="text-gray-700 mb-6">
                Contact Shri RK Homes today for personalized property recommendations, site visits, and expert guidance. Our team is available to answer all your queries and help you make the right investment decision.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/properties">
                  <Button className="bg-[#9c4915] hover:bg-[#7a3710]">
                    Browse Properties
                  </Button>
                </Link>
                <Button variant="outline" className="border-[#9c4915] text-[#9c4915] hover:bg-[#9c4915] hover:text-white bg-white" onClick={() => setIsContactModalOpen(true)}>
                  Contact Us
                </Button>
              </div>
            </div>
          </article>
        </div>
      </section>

      <Footer />

      {/* Modals */}
      <ContactFormModal isOpen={isContactModalOpen} onClose={() => setIsContactModalOpen(false)} />
      <SiteVisitModal isOpen={isSiteVisitModalOpen} onClose={() => setIsSiteVisitModalOpen(false)} />
      <OffersModal isOpen={isOffersModalOpen} onClose={() => setIsOffersModalOpen(false)} />
    </>;
};
export default HomePage;