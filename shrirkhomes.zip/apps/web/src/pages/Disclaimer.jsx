import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';

const Disclaimer = () => {
  return (
    <>
      <Helmet>
        <title>Disclaimer | Shri RK Homes</title>
        <meta name="description" content="Legal disclaimer for Shri RK Homes real estate services." />
      </Helmet>
      <Header />
      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'Disclaimer' }]} />
        <div className="max-w-4xl mx-auto py-12">
          <h1 className="text-4xl font-bold mb-8">Disclaimer</h1>
          <div className="prose prose-lg max-w-none text-gray-700">
            <p>The information provided on the Shri RK Homes website is for general informational purposes only. All information on the site is provided in good faith, however, we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the site.</p>
            <p>Property prices, availability, and specifications are subject to change without prior notice. The images used on the website are for representation purposes only and may not reflect the actual property.</p>
            <p>Shri RK Homes is a real estate consulting firm and acts as an intermediary between buyers and developers. We strongly advise all prospective buyers to independently verify all property details, legal documents, and RERA registration status before making any financial decisions.</p>
            <p>Financial calculators provided on the website are for estimation purposes only and do not constitute financial advice or a guarantee of loan approval.</p>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Disclaimer;