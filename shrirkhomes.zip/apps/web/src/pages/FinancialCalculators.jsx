import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Calculator, Home, DollarSign, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';

const FinancialCalculators = () => {
  // EMI Calculator State
  const [loanAmount, setLoanAmount] = useState(5000000);
  const [interestRate, setInterestRate] = useState(8.5);
  const [tenure, setTenure] = useState(20);

  // Affordability Calculator State
  const [monthlyIncome, setMonthlyIncome] = useState(100000);
  const [existingEMI, setExistingEMI] = useState(0);
  const [downPayment, setDownPayment] = useState(20);

  // Stamp Duty Calculator State
  const [propertyValue, setPropertyValue] = useState(5000000);
  const [stampDutyRate, setStampDutyRate] = useState(7);

  // EMI Calculation
  const calculateEMI = () => {
    const principal = loanAmount;
    const rate = interestRate / 12 / 100;
    const time = tenure * 12;
    const emi = (principal * rate * Math.pow(1 + rate, time)) / (Math.pow(1 + rate, time) - 1);
    const totalAmount = emi * time;
    const totalInterest = totalAmount - principal;
    return { emi: Math.round(emi), totalAmount: Math.round(totalAmount), totalInterest: Math.round(totalInterest) };
  };

  // Affordability Calculation
  const calculateAffordability = () => {
    const maxEMI = (monthlyIncome * 0.5) - existingEMI;
    const rate = 8.5 / 12 / 100;
    const time = 20 * 12;
    const maxLoan = (maxEMI * (Math.pow(1 + rate, time) - 1)) / (rate * Math.pow(1 + rate, time));
    const downPaymentAmount = (maxLoan * downPayment) / (100 - downPayment);
    const affordablePrice = maxLoan + downPaymentAmount;
    return { maxEMI: Math.round(maxEMI), maxLoan: Math.round(maxLoan), affordablePrice: Math.round(affordablePrice) };
  };

  // Stamp Duty Calculation
  const calculateStampDuty = () => {
    const stampDuty = (propertyValue * stampDutyRate) / 100;
    const registrationCharges = (propertyValue * 1) / 100;
    const totalCost = stampDuty + registrationCharges;
    return { stampDuty: Math.round(stampDuty), registrationCharges: Math.round(registrationCharges), totalCost: Math.round(totalCost) };
  };

  const emiResult = calculateEMI();
  const affordabilityResult = calculateAffordability();
  const stampDutyResult = calculateStampDuty();

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    "name": "Real Estate Financial Calculators",
    "description": "Free EMI calculator, affordability calculator, and stamp duty calculator for property buyers in Noida and Greater Noida.",
    "url": "https://shrirkhomes.com/calculators"
  };

  return (
    <>
      <Helmet>
        <title>Property Financial Calculators - EMI, Affordability, Stamp Duty | Shri RK Homes</title>
        <meta name="description" content="Free real estate financial calculators: EMI calculator for home loans, affordability calculator to determine budget, and stamp duty calculator for property registration costs in Noida and Greater Noida." />
        <meta name="keywords" content="EMI calculator, home loan calculator, affordability calculator, stamp duty calculator, property registration charges, real estate calculator Noida" />
        <link rel="canonical" href="https://shrirkhomes.com/calculators" />
        
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>

      <Header />

      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'Financial Calculators' }]} />
      </div>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-[#9c4915]/10 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Property Financial Calculators</h1>
            <p className="text-xl text-muted-foreground">
              Plan your property investment with our free financial calculators
            </p>
          </motion.div>
        </div>
      </section>

      {/* Calculators */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="emi" className="max-w-6xl mx-auto">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="emi">
                <Calculator className="w-4 h-4 mr-2" />
                EMI Calculator
              </TabsTrigger>
              <TabsTrigger value="affordability">
                <Home className="w-4 h-4 mr-2" />
                Affordability
              </TabsTrigger>
              <TabsTrigger value="stamp-duty">
                <FileText className="w-4 h-4 mr-2" />
                Stamp Duty
              </TabsTrigger>
            </TabsList>

            {/* EMI Calculator */}
            <TabsContent value="emi">
              <div className="grid lg:grid-cols-2 gap-8">
                <Card>
                  <CardContent className="p-8">
                    <h2 className="text-2xl font-bold mb-6">Home Loan EMI Calculator</h2>
                    <div className="space-y-6">
                      <div>
                        <Label>Loan Amount: {formatCurrency(loanAmount)}</Label>
                        <Input 
                          type="number" 
                          value={loanAmount} 
                          onChange={(e) => setLoanAmount(Number(e.target.value))}
                          className="mt-2 text-gray-900"
                        />
                      </div>
                      <div>
                        <Label>Interest Rate: {interestRate}% per annum</Label>
                        <Slider 
                          value={[interestRate]} 
                          onValueChange={(value) => setInterestRate(value[0])}
                          min={6}
                          max={15}
                          step={0.1}
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label>Loan Tenure</Label>
                        <Select value={tenure.toString()} onValueChange={(value) => setTenure(Number(value))}>
                          <SelectTrigger className="mt-2">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="5">5 Years</SelectItem>
                            <SelectItem value="10">10 Years</SelectItem>
                            <SelectItem value="15">15 Years</SelectItem>
                            <SelectItem value="20">20 Years</SelectItem>
                            <SelectItem value="25">25 Years</SelectItem>
                            <SelectItem value="30">30 Years</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-[#9c4915] to-[#7a3710] text-white">
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold mb-6">EMI Breakdown</h3>
                    <div className="space-y-6">
                      <div className="bg-white/10 p-4 rounded-lg">
                        <p className="text-sm opacity-90 mb-1">Monthly EMI</p>
                        <p className="text-3xl font-bold">{formatCurrency(emiResult.emi)}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white/10 p-4 rounded-lg">
                          <p className="text-sm opacity-90 mb-1">Principal Amount</p>
                          <p className="text-xl font-bold">{formatCurrency(loanAmount)}</p>
                        </div>
                        <div className="bg-white/10 p-4 rounded-lg">
                          <p className="text-sm opacity-90 mb-1">Total Interest</p>
                          <p className="text-xl font-bold">{formatCurrency(emiResult.totalInterest)}</p>
                        </div>
                      </div>
                      <div className="bg-white/10 p-4 rounded-lg">
                        <p className="text-sm opacity-90 mb-1">Total Amount Payable</p>
                        <p className="text-2xl font-bold">{formatCurrency(emiResult.totalAmount)}</p>
                      </div>
                      <Button variant="secondary" className="w-full">
                        Print Summary
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Affordability Calculator */}
            <TabsContent value="affordability">
              <div className="grid lg:grid-cols-2 gap-8">
                <Card>
                  <CardContent className="p-8">
                    <h2 className="text-2xl font-bold mb-6">Property Affordability Calculator</h2>
                    <div className="space-y-6">
                      <div>
                        <Label>Monthly Income: {formatCurrency(monthlyIncome)}</Label>
                        <Input 
                          type="number" 
                          value={monthlyIncome} 
                          onChange={(e) => setMonthlyIncome(Number(e.target.value))}
                          className="mt-2 text-gray-900"
                        />
                      </div>
                      <div>
                        <Label>Existing EMI Obligations: {formatCurrency(existingEMI)}</Label>
                        <Input 
                          type="number" 
                          value={existingEMI} 
                          onChange={(e) => setExistingEMI(Number(e.target.value))}
                          className="mt-2 text-gray-900"
                        />
                      </div>
                      <div>
                        <Label>Down Payment: {downPayment}%</Label>
                        <Slider 
                          value={[downPayment]} 
                          onValueChange={(value) => setDownPayment(value[0])}
                          min={10}
                          max={50}
                          step={5}
                          className="mt-2"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-blue-600 to-blue-700 text-white">
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold mb-6">You Can Afford</h3>
                    <div className="space-y-6">
                      <div className="bg-white/10 p-4 rounded-lg">
                        <p className="text-sm opacity-90 mb-1">Affordable Property Price</p>
                        <p className="text-3xl font-bold">{formatCurrency(affordabilityResult.affordablePrice)}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white/10 p-4 rounded-lg">
                          <p className="text-sm opacity-90 mb-1">Maximum EMI</p>
                          <p className="text-xl font-bold">{formatCurrency(affordabilityResult.maxEMI)}</p>
                        </div>
                        <div className="bg-white/10 p-4 rounded-lg">
                          <p className="text-sm opacity-90 mb-1">Maximum Loan</p>
                          <p className="text-xl font-bold">{formatCurrency(affordabilityResult.maxLoan)}</p>
                        </div>
                      </div>
                      <div className="bg-white/10 p-4 rounded-lg">
                        <p className="text-sm opacity-90 mb-1">Note</p>
                        <p className="text-sm">Based on 50% of income for EMI and 20-year tenure at 8.5% interest</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Stamp Duty Calculator */}
            <TabsContent value="stamp-duty">
              <div className="grid lg:grid-cols-2 gap-8">
                <Card>
                  <CardContent className="p-8">
                    <h2 className="text-2xl font-bold mb-6">Stamp Duty & Registration Calculator</h2>
                    <div className="space-y-6">
                      <div>
                        <Label>Property Value: {formatCurrency(propertyValue)}</Label>
                        <Input 
                          type="number" 
                          value={propertyValue} 
                          onChange={(e) => setPropertyValue(Number(e.target.value))}
                          className="mt-2 text-gray-900"
                        />
                      </div>
                      <div>
                        <Label>Stamp Duty Rate: {stampDutyRate}%</Label>
                        <div className="flex gap-2 mt-2">
                          <Button 
                            variant={stampDutyRate === 5 ? "default" : "outline"}
                            onClick={() => setStampDutyRate(5)}
                            className={stampDutyRate === 5 ? "bg-[#9c4915]" : ""}
                          >
                            5%
                          </Button>
                          <Button 
                            variant={stampDutyRate === 6 ? "default" : "outline"}
                            onClick={() => setStampDutyRate(6)}
                            className={stampDutyRate === 6 ? "bg-[#9c4915]" : ""}
                          >
                            6%
                          </Button>
                          <Button 
                            variant={stampDutyRate === 7 ? "default" : "outline"}
                            onClick={() => setStampDutyRate(7)}
                            className={stampDutyRate === 7 ? "bg-[#9c4915]" : ""}
                          >
                            7%
                          </Button>
                        </div>
                        <Slider 
                          value={[stampDutyRate]} 
                          onValueChange={(value) => setStampDutyRate(value[0])}
                          min={4}
                          max={10}
                          step={0.5}
                          className="mt-4"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-green-600 to-green-700 text-white">
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold mb-6">Cost Breakdown</h3>
                    <div className="space-y-6">
                      <div className="bg-white/10 p-4 rounded-lg">
                        <p className="text-sm opacity-90 mb-1">Total Registration Cost</p>
                        <p className="text-3xl font-bold">{formatCurrency(stampDutyResult.totalCost)}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white/10 p-4 rounded-lg">
                          <p className="text-sm opacity-90 mb-1">Stamp Duty</p>
                          <p className="text-xl font-bold">{formatCurrency(stampDutyResult.stampDuty)}</p>
                        </div>
                        <div className="bg-white/10 p-4 rounded-lg">
                          <p className="text-sm opacity-90 mb-1">Registration</p>
                          <p className="text-xl font-bold">{formatCurrency(stampDutyResult.registrationCharges)}</p>
                        </div>
                      </div>
                      <div className="bg-white/10 p-4 rounded-lg">
                        <p className="text-sm opacity-90 mb-1">Note</p>
                        <p className="text-sm">Rates may vary by state and property type. Consult with our experts for accurate calculations.</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Explanatory Content */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <article className="prose prose-lg max-w-none">
            <h2 className="text-3xl font-bold mb-6">Understanding Property Financial Calculations</h2>
            
            <p className="text-gray-700 mb-6">
              Making informed financial decisions is crucial when investing in real estate. Our suite of property financial calculators is designed to help homebuyers and investors in Noida, Greater Noida, and Yamuna Expressway plan their investments accurately. Whether you're calculating your monthly EMI, determining your affordability, or estimating registration costs, these tools provide instant, reliable estimates.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">How to Use the EMI Calculator</h3>
            <p className="text-gray-700 mb-6">
              The Equated Monthly Installment (EMI) calculator helps you understand your monthly financial commitment towards a home loan. Simply input the loan amount you need, the expected interest rate, and the loan tenure. The calculator instantly provides your monthly EMI, total interest payable, and the total amount you will pay over the loan tenure. This helps you compare different loan offers and choose a tenure that fits your monthly budget.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Determining Your Property Affordability</h3>
            <p className="text-gray-700 mb-6">
              Before starting your property search, it's essential to know your budget. Our affordability calculator takes into account your monthly income, existing financial obligations (like car loans or personal loans), and the down payment you can afford. Based on standard banking norms (where EMI shouldn't exceed 50% of your net income), it calculates the maximum loan you are eligible for and the total property price you can comfortably afford.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Estimating Stamp Duty and Registration Charges</h3>
            <p className="text-gray-700 mb-6">
              Stamp duty and registration charges are significant additional costs when buying property. In Uttar Pradesh (including Noida and Greater Noida), these charges typically range from 5% to 7% depending on the property type, location, and the gender of the buyer (women often get a rebate). Use our estimator to calculate these mandatory government charges so you can factor them into your total property acquisition budget.
            </p>
          </article>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default FinancialCalculators;