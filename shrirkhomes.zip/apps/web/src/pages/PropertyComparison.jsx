import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Check, X, Printer, Download, Plus, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import { useToast } from '@/hooks/use-toast';
import { jsPDF } from 'jspdf';

const PropertyComparison = () => {
  const { toast } = useToast();
  
  // Mock data for comparison
  const [compareList, setCompareList] = useState([
    {
      id: 1,
      title: 'Luxury 3 BHK Apartment',
      location: 'Sector 137, Noida',
      image: 'https://images.unsplash.com/photo-1685279053124-f47a436a9c1e?auto=format&fit=crop&w=800&q=80',
      price: '₹85 Lakhs',
      pricePerSqft: '₹5,862/sq.ft',
      area: '1450 sq.ft',
      type: 'High-Rise',
      status: 'Ready to Move',
      rera: 'Yes',
      builder: 'Premium Developers',
      possession: 'Immediate',
      maintenance: '₹3,500/month',
      amenities: ['Pool', 'Gym', 'Clubhouse', 'Security'],
      pros: ['Prime location', 'Ready to move', 'Good amenities'],
      cons: ['Higher maintenance', 'Older construction']
    },
    {
      id: 2,
      title: 'Premium 4 BHK Builder Floor',
      location: 'Greater Noida West',
      image: 'https://images.unsplash.com/photo-1697206583430-d7e51ab8223e?auto=format&fit=crop&w=800&q=80',
      price: '₹1.2 Cr',
      pricePerSqft: '₹5,454/sq.ft',
      area: '2200 sq.ft',
      type: 'Builder Floor',
      status: 'Under Construction',
      rera: 'Yes',
      builder: 'RK Constructions',
      possession: 'Dec 2024',
      maintenance: '₹1,500/month',
      amenities: ['Parking', 'Terrace', 'Security'],
      pros: ['Freehold property', 'Low maintenance', 'Spacious'],
      cons: ['Under construction', 'Fewer amenities']
    },
    {
      id: 3,
      title: 'Modern 3 BHK Flat',
      location: 'Sector 150, Noida',
      image: 'https://images.unsplash.com/photo-1700842240282-8db1cb01dbf4?auto=format&fit=crop&w=800&q=80',
      price: '₹95 Lakhs',
      pricePerSqft: '₹5,757/sq.ft',
      area: '1650 sq.ft',
      type: 'High-Rise',
      status: 'New Launch',
      rera: 'Yes',
      builder: 'Elite Builders',
      possession: 'Mar 2026',
      maintenance: '₹4,000/month',
      amenities: ['Pool', 'Gym', 'Sports Court', 'Smart Home'],
      pros: ['Modern design', 'Sports facilities', 'Green area'],
      cons: ['Long wait time', 'High price']
    }
  ]);

  const removeProperty = (id) => {
    setCompareList(compareList.filter(p => p.id !== id));
    toast({
      title: "Property Removed",
      description: "Property has been removed from comparison.",
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    if (compareList.length === 0) {
      toast({
        title: "No Properties",
        description: "Please add properties to compare before downloading.",
        variant: "destructive"
      });
      return;
    }

    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      
      // Header
      doc.setFontSize(24);
      doc.setTextColor(156, 73, 21); // #9c4915
      doc.text("Shri RK Homes", pageWidth / 2, 20, { align: "center" });
      
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text("TOGETHER, TOWARDS A BETTER TOMORROW", pageWidth / 2, 26, { align: "center" });
      
      doc.setFontSize(16);
      doc.setTextColor(0, 0, 0);
      doc.text("Property Comparison Report", pageWidth / 2, 40, { align: "center" });
      
      doc.setLineWidth(0.5);
      doc.line(14, 45, pageWidth - 14, 45);

      let yPos = 55;

      // Iterate through properties and create a structured list
      compareList.forEach((prop, index) => {
        // Check if we need a new page
        if (yPos > 250) {
          doc.addPage();
          yPos = 20;
        }

        doc.setFontSize(14);
        doc.setTextColor(156, 73, 21);
        doc.text(`${index + 1}. ${prop.title}`, 14, yPos);
        yPos += 8;

        doc.setFontSize(10);
        doc.setTextColor(0, 0, 0);
        
        const details = [
          `Location: ${prop.location}`,
          `Price: ${prop.price} (${prop.pricePerSqft})`,
          `Area: ${prop.area}`,
          `Type: ${prop.type}`,
          `Status: ${prop.status}`,
          `Possession: ${prop.possession}`,
          `Builder: ${prop.builder}`,
          `RERA Approved: ${prop.rera}`,
          `Maintenance: ${prop.maintenance}`
        ];

        // Print details in two columns
        details.forEach((detail, i) => {
          const xPos = i % 2 === 0 ? 20 : pageWidth / 2;
          doc.text(detail, xPos, yPos);
          if (i % 2 !== 0) yPos += 6;
        });
        
        if (details.length % 2 !== 0) yPos += 6; // Adjust if odd number of details

        yPos += 2;
        doc.setFont(undefined, 'bold');
        doc.text("Amenities:", 20, yPos);
        doc.setFont(undefined, 'normal');
        doc.text(prop.amenities.join(", "), 45, yPos);
        yPos += 6;

        doc.setFont(undefined, 'bold');
        doc.setTextColor(0, 128, 0); // Green
        doc.text("Pros:", 20, yPos);
        doc.setFont(undefined, 'normal');
        doc.text(prop.pros.join(", "), 35, yPos);
        yPos += 6;

        doc.setFont(undefined, 'bold');
        doc.setTextColor(255, 0, 0); // Red
        doc.text("Cons:", 20, yPos);
        doc.setFont(undefined, 'normal');
        doc.text(prop.cons.join(", "), 35, yPos);
        
        yPos += 15;
        doc.setTextColor(0, 0, 0); // Reset color
        doc.setLineWidth(0.2);
        doc.line(14, yPos - 5, pageWidth - 14, yPos - 5);
      });

      // Footer
      const pageCount = doc.internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text(
          "Shri RK Homes | Noida, UP | +91 7303459116 | sales@shrirkhomes.com",
          pageWidth / 2,
          doc.internal.pageSize.getHeight() - 10,
          { align: "center" }
        );
      }

      doc.save("property-comparison.pdf");
      
      toast({
        title: "Success",
        description: "PDF downloaded successfully.",
      });
    } catch (error) {
      console.error("PDF Generation Error:", error);
      toast({
        title: "Error",
        description: "Failed to generate PDF. Please try again.",
        variant: "destructive"
      });
    }
  };

  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    "name": "Property Comparison Tool",
    "description": "Compare real estate properties side-by-side in Noida and Greater Noida.",
    "url": "https://shrirkhomes.com/comparison"
  };

  return (
    <>
      <Helmet>
        <title>Compare Properties - Real Estate Comparison Tool | Shri RK Homes</title>
        <meta name="description" content="Compare multiple properties side-by-side. Evaluate prices, amenities, RERA status, and locations of apartments and builder floors in Noida and Greater Noida." />
        <meta name="keywords" content="compare properties Noida, real estate comparison tool, compare apartments Greater Noida, property evaluation" />
        <link rel="canonical" href="https://shrirkhomes.com/comparison" />
        
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>

      <Header />

      <div className="container mx-auto px-4 py-8 print:hidden">
        <Breadcrumb items={[{ label: 'Compare Properties' }]} />
      </div>

      {/* Hero Section */}
      <section className="py-12 bg-gradient-to-br from-[#9c4915]/10 to-white print:hidden">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-2xl"
            >
              <h1 className="text-4xl font-bold mb-4">Compare Properties</h1>
              <p className="text-xl text-muted-foreground">
                Evaluate properties side-by-side to make an informed decision
              </p>
            </motion.div>
            <div className="flex gap-4">
              <Button variant="outline" onClick={handlePrint} className="border-[#9c4915] text-[#9c4915]">
                <Printer className="w-4 h-4 mr-2" />
                Print
              </Button>
              <Button onClick={handleDownload} className="bg-[#9c4915] hover:bg-[#7a3710]">
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {compareList.length === 0 ? (
            <div className="text-center py-16 bg-gray-50 rounded-lg">
              <h2 className="text-2xl font-bold mb-4">No Properties Selected</h2>
              <p className="text-muted-foreground mb-6">Add properties from the listing page to compare them here.</p>
              <Link to="/properties">
                <Button className="bg-[#9c4915] hover:bg-[#7a3710]">
                  Browse Properties
                </Button>
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[800px] border-collapse bg-white shadow-sm rounded-lg overflow-hidden">
                <thead>
                  <tr>
                    <th className="p-4 border-b border-r bg-gray-50 w-48 text-left font-semibold">
                      Property Details
                    </th>
                    {compareList.map((property) => (
                      <th key={property.id} className="p-4 border-b border-r relative min-w-[250px] align-top">
                        <button 
                          onClick={() => removeProperty(property.id)}
                          className="absolute top-2 right-2 p-1 bg-red-100 text-red-600 rounded-full hover:bg-red-200 transition-colors print:hidden z-10"
                          aria-label="Remove property"
                        >
                          <X className="w-4 h-4" />
                        </button>
                        <img 
                          src={property.image} 
                          alt={property.title}
                          className="w-full h-40 object-cover rounded-lg mb-4"
                        />
                        <h3 className="font-bold text-lg mb-1">{property.title}</h3>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground mb-2">
                          <MapPin className="w-3 h-3" />
                          {property.location}
                        </div>
                        <p className="text-xl font-bold text-[#9c4915]">{property.price}</p>
                      </th>
                    ))}
                    {compareList.length < 4 && (
                      <th className="p-4 border-b bg-gray-50 min-w-[250px] align-middle text-center print:hidden">
                        <Link to="/properties">
                          <Button variant="outline" className="border-dashed border-2 border-gray-300 h-32 w-full flex flex-col items-center justify-center text-gray-500 hover:text-[#9c4915] hover:border-[#9c4915]">
                            <Plus className="w-8 h-8 mb-2" />
                            Add Property
                          </Button>
                        </Link>
                      </th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {/* Basic Details */}
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold">Property Type</td>
                    {compareList.map(p => <td key={p.id} className="p-4 border-b border-r">{p.type}</td>)}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold">Carpet Area</td>
                    {compareList.map(p => <td key={p.id} className="p-4 border-b border-r">{p.area}</td>)}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold">Price per sq.ft</td>
                    {compareList.map(p => <td key={p.id} className="p-4 border-b border-r">{p.pricePerSqft}</td>)}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>
                  
                  {/* Status & Legal */}
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold">Status</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-4 border-b border-r">
                        <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-sm">{p.status}</span>
                      </td>
                    ))}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold">Possession</td>
                    {compareList.map(p => <td key={p.id} className="p-4 border-b border-r">{p.possession}</td>)}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold">RERA Approved</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-4 border-b border-r">
                        {p.rera === 'Yes' ? <Check className="w-5 h-5 text-green-600" /> : <X className="w-5 h-5 text-red-600" />}
                      </td>
                    ))}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold">Builder</td>
                    {compareList.map(p => <td key={p.id} className="p-4 border-b border-r">{p.builder}</td>)}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>

                  {/* Financials */}
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold">Maintenance</td>
                    {compareList.map(p => <td key={p.id} className="p-4 border-b border-r">{p.maintenance}</td>)}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>

                  {/* Amenities */}
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold align-top">Amenities</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-4 border-b border-r align-top">
                        <ul className="space-y-1">
                          {p.amenities.map((amenity, idx) => (
                            <li key={idx} className="flex items-center gap-2 text-sm">
                              <Check className="w-3 h-3 text-[#9c4915]" />
                              {amenity}
                            </li>
                          ))}
                        </ul>
                      </td>
                    ))}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>

                  {/* Pros & Cons */}
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold align-top">Pros</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-4 border-b border-r align-top bg-green-50/30">
                        <ul className="space-y-1">
                          {p.pros.map((pro, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm">
                              <span className="text-green-600 mt-0.5">+</span>
                              {pro}
                            </li>
                          ))}
                        </ul>
                      </td>
                    ))}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>
                  <tr>
                    <td className="p-4 border-b border-r bg-gray-50 font-semibold align-top">Cons</td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-4 border-b border-r align-top bg-red-50/30">
                        <ul className="space-y-1">
                          {p.cons.map((con, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm">
                              <span className="text-red-600 mt-0.5">-</span>
                              {con}
                            </li>
                          ))}
                        </ul>
                      </td>
                    ))}
                    {compareList.length < 4 && <td className="p-4 border-b bg-gray-50 print:hidden"></td>}
                  </tr>

                  {/* Action */}
                  <tr className="print:hidden">
                    <td className="p-4 border-r bg-gray-50"></td>
                    {compareList.map(p => (
                      <td key={p.id} className="p-4 border-r text-center">
                        <Link to={`/property/${p.id}`}>
                          <Button className="w-full bg-[#9c4915] hover:bg-[#7a3710]">
                            View Details
                          </Button>
                        </Link>
                      </td>
                    ))}
                    {compareList.length < 4 && <td className="p-4 bg-gray-50"></td>}
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      {/* SEO Content */}
      <section className="py-16 bg-gray-50 print:hidden">
        <div className="container mx-auto px-4 max-w-4xl">
          <article className="prose prose-lg max-w-none">
            <h2 className="text-3xl font-bold mb-6">Make Informed Decisions with Our Property Comparison Tool</h2>
            
            <p className="text-gray-700 mb-6">
              Choosing the right property is a significant decision that requires careful evaluation of multiple factors. Our advanced property comparison tool allows you to evaluate up to 4 properties side-by-side, making it easier to identify the best investment for your needs in Noida, Greater Noida, or Yamuna Expressway.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">What to Look for When Comparing Properties</h3>
            <p className="text-gray-700 mb-6">
              When comparing real estate options, look beyond just the total price. Pay attention to the price per square foot, carpet area versus super built-up area, and possession timelines. Evaluate the RERA status, builder reputation, and monthly maintenance charges. Our tool highlights the pros and cons of each property, helping you weigh the trade-offs between location, amenities, and budget.
            </p>
          </article>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default PropertyComparison;