import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Building2, Home, Store, Shield, CheckCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';

const Services = () => {
  const services = [
    {
      id: 'high-rise',
      icon: Building2,
      title: 'High-Rise Projects',
      subtitle: 'Luxury Apartments with Modern Amenities',
      description: 'Discover premium high-rise apartments in Noida and Greater Noida featuring world-class amenities, 24/7 security, and prime locations.',
      image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1000&q=80',
      features: [
        'Luxury 2/3/4 BHK apartments',
        'Modern amenities: Swimming pool, gym, clubhouse',
        '24/7 security with CCTV surveillance',
        'Prime locations with excellent connectivity',
        'RERA approved projects',
        'Ready-to-move and under-construction options'
      ],
      benefits: [
        'High appreciation potential',
        'Rental income opportunities',
        'Gated community living',
        'Professional property management'
      ]
    },
    {
      id: 'builder-floors',
      icon: Home,
      title: 'Builder Floors',
      subtitle: 'Freehold Properties with Independent Living',
      description: 'Explore premium builder floors in Greater Noida offering freehold ownership, customizable designs, and independent living spaces.',
      image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=80',
      features: [
        'Freehold property ownership',
        'Customizable floor plans and interiors',
        '3/4/5 BHK independent floors',
        'Lower maintenance costs',
        'Private parking and terrace',
        'Prime residential localities'
      ],
      benefits: [
        'Complete ownership and control',
        'No society maintenance hassles',
        'Better privacy and independence',
        'Higher resale value'
      ]
    },
    {
      id: 'commercial',
      icon: Store,
      title: 'Commercial Properties',
      subtitle: 'Office Spaces and Retail Properties',
      description: 'Invest in commercial properties on Yamuna Expressway with high ROI potential, excellent connectivity, and modern infrastructure.',
      image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1000&q=80',
      features: [
        'Office spaces and retail shops',
        'Strategic locations on Yamuna Expressway',
        'High footfall areas',
        'Modern infrastructure',
        'Flexible payment plans',
        'RERA registered projects'
      ],
      benefits: [
        'High rental yields (8-12%)',
        'Capital appreciation potential',
        'Business growth opportunities',
        'Tax benefits on commercial property'
      ]
    },
    {
      id: 'rera',
      icon: Shield,
      title: 'RERA Guidance & Support',
      subtitle: 'Complete Legal and Documentation Assistance',
      description: 'Comprehensive RERA compliance support ensuring transparent transactions, legal protection, and complete documentation assistance.',
      image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1000&q=80',
      features: [
        'RERA registration verification',
        'Complete documentation support',
        'Legal compliance checks',
        'Builder credential verification',
        'Title verification services',
        'Home loan processing assistance'
      ],
      benefits: [
        'Legal protection for buyers',
        'Transparent pricing and timelines',
        'Dispute resolution support',
        'Peace of mind in transactions'
      ]
    }
  ];

  const processSteps = [
    { step: 1, title: 'Consultation', description: 'Understand your requirements and budget' },
    { step: 2, title: 'Property Search', description: 'Curated property recommendations' },
    { step: 3, title: 'Site Visits', description: 'Organized property tours with experts' },
    { step: 4, title: 'Documentation', description: 'Complete legal and RERA verification' },
    { step: 5, title: 'Negotiation', description: 'Best price and payment plan assistance' },
    { step: 6, title: 'Registration', description: 'Property registration and handover' }
  ];

  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "Shri RK Homes",
    "description": "Premium real estate services including high-rise apartments, builder floors, commercial properties, and RERA guidance in Noida, Greater Noida, and Yamuna Expressway.",
    "url": "https://shrirkhomes.com/services",
    "priceRange": "₹₹₹",
    "areaServed": ["Noida", "Greater Noida", "Yamuna Expressway"]
  };

  return (
    <>
      <Helmet>
        <title>Real Estate Services - High-Rise, Builder Floors, Commercial | Shri RK Homes</title>
        <meta name="description" content="Comprehensive real estate services by Shri RK Homes: Luxury high-rise apartments, freehold builder floors, commercial properties, and complete RERA guidance in Noida, Greater Noida, and Yamuna Expressway." />
        <meta name="keywords" content="real estate services Noida, high-rise apartments, builder floors Greater Noida, commercial property Yamuna Expressway, RERA guidance, property documentation support, real estate consultant" />
        <link rel="canonical" href="https://shrirkhomes.com/services" />
        
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>

      <Header />

      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'Services' }]} />
      </div>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-[#9c4915]/10 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Premium Real Estate Services</h1>
            <p className="text-xl text-muted-foreground">
              Comprehensive property solutions tailored to your needs with complete RERA compliance and transparent processes
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Detail */}
      {services.map((service, index) => {
        const Icon = service.icon;
        return (
          <section key={service.id} id={service.id} className={`py-16 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
            <div className="container mx-auto px-4">
              <div className="max-w-6xl mx-auto">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="grid md:grid-cols-2 gap-12 items-center"
                >
                  <div className={index % 2 === 0 ? 'order-1' : 'order-2'}>
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-16 h-16 bg-[#9c4915]/10 rounded-lg flex items-center justify-center">
                        <Icon className="w-8 h-8 text-[#9c4915]" />
                      </div>
                      <div>
                        <h2 className="text-3xl font-bold">{service.title}</h2>
                        <p className="text-[#9c4915] font-semibold">{service.subtitle}</p>
                      </div>
                    </div>
                    <p className="text-lg text-gray-700 mb-6">{service.description}</p>
                    <div className="mb-6 rounded-xl overflow-hidden shadow-md h-64">
                      <img src={service.image} alt={service.title} className="w-full h-full object-cover" />
                    </div>
                    <Link to="/properties">
                      <Button className="bg-[#9c4915] hover:bg-[#7a3710]">
                        View Properties
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </Link>
                  </div>

                  <div className={index % 2 === 0 ? 'order-2' : 'order-1'}>
                    <Card>
                      <CardContent className="p-6">
                        <h3 className="text-xl font-bold mb-4">Key Features</h3>
                        <ul className="space-y-2 mb-6">
                          {service.features.map((feature, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                              <span className="text-gray-700">{feature}</span>
                            </li>
                          ))}
                        </ul>
                        <h3 className="text-xl font-bold mb-4">Benefits</h3>
                        <ul className="space-y-2">
                          {service.benefits.map((benefit, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <CheckCircle className="w-5 h-5 text-[#9c4915] flex-shrink-0 mt-0.5" />
                              <span className="text-gray-700">{benefit}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                </motion.div>
              </div>
            </div>
          </section>
        );
      })}

      {/* Process Flow */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Service Process</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              A streamlined approach to make your property buying journey smooth and hassle-free
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-6 max-w-6xl mx-auto">
            {processSteps.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="text-center h-full">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-[#9c4915] text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                      {item.step}
                    </div>
                    <h3 className="font-bold mb-2">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Content */}
      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <article className="prose prose-lg max-w-none">
            <h2 className="text-3xl font-bold mb-6">Comprehensive Real Estate Solutions in Noida and Greater Noida</h2>
            
            <p className="text-gray-700 mb-6">
              Shri RK Homes offers a complete spectrum of real estate services designed to meet the diverse needs of homebuyers, investors, and businesses across Noida, Greater Noida, and Yamuna Expressway. Our expertise spans residential and commercial properties, with a strong focus on RERA compliance, transparent processes, and customer satisfaction.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Why Choose Our Services?</h3>
            <p className="text-gray-700 mb-6">
              With years of experience in the NCR real estate market, we have built a reputation for reliability, transparency, and excellence. Our team of property consultants, legal experts, and customer service professionals work together to ensure every client receives personalized attention and comprehensive support throughout their property journey.
            </p>

            <p className="text-gray-700 mb-6">
              We understand that buying property is a significant financial decision, and we are committed to making the process as smooth and stress-free as possible. From initial consultation to final handover, we provide end-to-end assistance, ensuring complete transparency and legal compliance at every step.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Contact Us for Personalized Service</h3>
            <p className="text-gray-700 mb-6">
              Ready to explore premium properties in Noida, Greater Noida, or Yamuna Expressway? Contact Shri RK Homes today for personalized property recommendations, site visit arrangements, and expert guidance. Our team is available to answer all your queries and help you find the perfect property that matches your requirements and budget.
            </p>
          </article>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default Services;