import React, { useState, useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Home, IndianRupee, Maximize, Filter, Plus, X, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import { useToast } from '@/hooks/use-toast';

const defaultProperties = [
  {
    id: 1,
    title: 'SKA Destiny One',
    location: 'Zeta 1, Greater Noida',
    type: 'Residential-High-Rise',
    price: '₹11000 sq.ft',
    bhk: '3&4 BHK',
    area: '1050 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/ska-destiny-one-CklUi.jpg'
  },
  {
    id: 2,
    title: 'SKA Estate',
    location: 'Eta 2, Greater Noida',
    type: 'Residential-High Rise',
    price: '₹11000 sq.ft',
    bhk: '3&4 BHK',
    area: '1050 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/ska-estate-MXwQc.PNG'
  },
  {
    id: 3,
    title: 'Sobha Rivana',
    location: 'Sector 1, Greater Noida West',
    type: 'Residential-High Rise',
    price: '₹14888 sq.ft',
    bhk: '2,3&4 BHK',
    area: '1050 sq.ft',
    status: 'New Launch',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/sobha-sector-1-E9OZn.jpg'
  },
  {
    id: 4,
    title: 'Elite  X',
    location: 'Sector 10, Greater Noida West',
    type: 'Residential-High-Rise',
    price: '₹11000 sq.ft',
    bhk: '3&4 BHK',
    area: '1050 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/elite-x-m8WSm.jpg'
  },
  {
    id: 5,
    title: 'Ashtech  Presendential',
    location: 'Sector 12, Greater Noida West',
    type: 'Residential-High Rise',
    price: '₹12000 sq.ft',
    bhk: '3&4 BHK',
    area: '3500 sq.ft',
    status: 'New Launch',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/ashtech-presendential-Hy061.jpg'
  },
  {
    id: 6,
    title: 'Arihant Seasons',
    location: 'Sector 22D, Yamuna Expressway',
    type: 'Residential-High Rise',
    price: '₹8345 sq.ft',
    bhk: '2,3&4 BHK',
    area: '1800 sq.ft',
    status: 'New Launch',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/arihant-seasons-tbpr8.jpg'
  },
  {
    id: 7,
    title: 'Gaur-Chrysalis',
    location: 'Sector 22D, Yamuna Expressway',
    type: 'Residential-High-Rise',
    price: '₹8999 sq.ft',
    bhk: '3&4 BHK',
    area: '1650 sq.ft',
    status: 'New Launch',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/gaur-chrysalis-hOxKL.webp'
  },
  {
    id: 8,
    title: 'Eldeco Whispers of Wonder',
    location: 'Sector 22A, Yamuna expressway',
    type: 'Residential-High-Rise',
    price: '₹8999 Sq Ft.',
    bhk: '3,4,5BHK',
    area: '2500 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/1758024839747_ace_terra_desktop_banner_-_my_property_facts-q8ncv.webp'
  },
  {
    id: 9,
    title: 'Exotica 132',
    location: 'Sector 132, Noida',
    type: 'Commercial, Retail & Office Spaces',
    price: '₹13990 sq.ft',
    bhk: 'NA',
    area: '1200 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/image_search_1709821064492-1-1024x613-3uu7P.png'
  },
  {
    id: 10,
    title: 'AU Aspire Silicon city',
    location: 'Sector 76, Noida',
    type: 'Residential-High-Rise',
    price: '₹13000 sq.ft',
    bhk: '3&4BHK',
    area: '1500 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/au-aspire-silicon-city-1-ZSOdm.png'
  },
  {
    id: 11,
    title: 'Ivory County',
    location: 'Sector 115, Noida',
    type: 'Residential-High-Rise',
    price: '₹16000 sq.ft',
    bhk: '3,4&5BHK',
    area: '2000 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/ivory-county-FGWaY.png'
  },
  {
    id: 12,
    title: 'ACE Medalleo',
    location: 'Sector 107, Noida',
    type: 'Residential-High-Rise',
    price: '₹17000 sq.ft',
    bhk: '3&4BHK',
    area: '1400 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/ace-mahagun-medalleo-banner-94644-uOQ9J.jpg'
  },
  {
    id: 13,
    title: 'CRC Maesta',
    location: 'Sec 1, Greater Noida West',
    type: 'Residential-High-Rise',
    price: '₹14000 sq.ft',
    bhk: '3&4BHK',
    area: '1500 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/crc-maesta-ilfSM.jpeg'
  },
  {
    id: 14,
    title: 'Gaur Aspire Leisure Park',
    location: 'Sec 1, Greater Noida West',
    type: 'Residential-High-Rise',
    price: '₹11000 sq.ft',
    bhk: '3&4BHK',
    area: '2000 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/gaur-aspire-leisure-park-1-Kk1zV.jpg'
  },
  {
    id: 15,
    title: 'Nirala Trio',
    location: 'Sec 1, Greater Noida West',
    type: 'Residential-High-Rise',
    price: '₹10500 sq.ft',
    bhk: '2,3&4 BHK',
    area: '3000 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/nirala-trio-mt7KO.jpg'
  },
  {
    id: 16,
    title: 'Nirala Gateway',
    location: 'Sec 12, Greater Noida West',
    type: 'Studio/Commercial',
    price: '₹11500 sq.ft',
    bhk: 'ShopStudio/Retail',
    area: '2500 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/nirala-gateway-sector-12-banner-16597-vRNoL.jpg'
  },
  {
    id: 17,
    title: 'Sobha Aurum',
    location: 'Sec 36, Greater Noida',
    type: 'Residential-High-Rise',
    price: '₹13999 sq.ft',
    bhk: '2,3&4BHK',
    area: '2500 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/sobha-aurum-banner-AvEpk.jpg'
  },
  {
    id: 18,
    title: 'Northwind Sanctuary',
    location: 'Sector PI, Greater Noida',
    type: 'Residential-High-Rise',
    price: '₹13000 sq.ft',
    bhk: '3&4BHK',
    area: '2500 sq.ft',
    status: 'Under Construction',
    rera: 'Yes',
    image: 'https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/northwind-sanctuary-utkmP.jpg'
  }
];

const PropertyListing = () => {
  const { toast } = useToast();
  const [properties, setProperties] = useState([]);
  const [selectedProperties, setSelectedProperties] = useState([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const fileInputRef = useRef(null);

  // Filters State
  const [filters, setFilters] = useState({
    location: 'all',
    type: 'all',
    budget: 'all',
    bhk: 'all',
    status: 'all',
    rera: 'all'
  });

  // New Property Form State
  const [newProperty, setNewProperty] = useState({
    title: '', location: '', type: '', price: '', area: '', bhk: '', status: '', rera: 'Yes', description: '', image: '', builder: '', maintenance: ''
  });

  useEffect(() => {
    const savedProperties = localStorage.getItem('rk_properties');
    if (savedProperties) {
      setProperties(JSON.parse(savedProperties));
    } else {
      setProperties(defaultProperties);
    }
  }, []);

  const handleAddToCompare = (propertyId) => {
    if (selectedProperties.includes(propertyId)) {
      setSelectedProperties(selectedProperties.filter(id => id !== propertyId));
      toast({ title: "Removed from comparison", description: "Property removed from comparison list" });
    } else if (selectedProperties.length >= 4) {
      toast({ title: "Maximum limit reached", description: "You can compare up to 4 properties at a time", variant: "destructive" });
    } else {
      setSelectedProperties([...selectedProperties, propertyId]);
      toast({ title: "Added to comparison", description: "Property added to comparison list" });
    }
  };

  const parsePrice = (priceStr) => {
    if (!priceStr) return 0;
    const str = priceStr.toLowerCase();
    let val = parseFloat(str.replace(/[^0-9.]/g, ''));
    if (str.includes('cr')) val *= 100; // Convert Cr to Lakhs
    return val;
  };

  const filteredProperties = properties.filter(p => {
    let match = true;
    
    if (filters.location !== 'all' && !p.location.toLowerCase().includes(filters.location.toLowerCase().replace('-', ' '))) match = false;
    if (filters.type !== 'all' && p.type.toLowerCase().replace(' ', '-') !== filters.type) match = false;
    
    if (filters.budget !== 'all') {
      const price = parsePrice(p.price);
      if (filters.budget === '0-50' && price > 50) match = false;
      if (filters.budget === '50-100' && (price <= 50 || price > 100)) match = false;
      if (filters.budget === '100-200' && (price <= 100 || price > 200)) match = false;
      if (filters.budget === '200+' && price <= 200) match = false;
    }

    if (filters.bhk !== 'all') {
      if (filters.bhk === '5+' && parseInt(p.bhk) < 5) match = false;
      else if (filters.bhk !== '5+' && !p.bhk.includes(filters.bhk)) match = false;
    }

    if (filters.status !== 'all' && p.status.toLowerCase().replace(' ', '-') !== filters.status) match = false;
    if (filters.rera !== 'all' && p.rera.toLowerCase() !== filters.rera) match = false;

    return match;
  });

  const resetFilters = () => {
    setFilters({ location: 'all', type: 'all', budget: 'all', bhk: 'all', status: 'all', rera: 'all' });
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast({ title: "Invalid file type", description: "Please upload an image file.", variant: "destructive" });
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewProperty({ ...newProperty, image: reader.result });
        toast({ title: "Image uploaded", description: "Image has been successfully attached." });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddProperty = (e) => {
    e.preventDefault();
    const property = {
      id: Date.now(),
      title: newProperty.title,
      location: newProperty.location,
      type: newProperty.type,
      price: `₹${newProperty.price} Lakhs`,
      bhk: newProperty.bhk.includes('BHK') || newProperty.bhk === 'Office' || newProperty.bhk === 'Shop' ? newProperty.bhk : `${newProperty.bhk} BHK`,
      area: `${newProperty.area} sq.ft`,
      status: newProperty.status,
      rera: newProperty.rera,
      image: newProperty.image || 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=1000&q=80'
    };

    const updatedProperties = [property, ...properties];
    setProperties(updatedProperties);
    localStorage.setItem('rk_properties', JSON.stringify(updatedProperties));
    setIsAddModalOpen(false);
    setNewProperty({ title: '', location: '', type: '', price: '', area: '', bhk: '', status: '', rera: 'Yes', description: '', image: '', builder: '', maintenance: '' });
    toast({ title: "Success", description: "Property added successfully!" });
  };

  return (
    <>
      <Helmet>
        <title>Properties for Sale in Noida, Greater Noida | Shri RK Homes</title>
        <meta name="description" content="Browse premium properties for sale in Noida, Greater Noida, and Yamuna Expressway. Find luxury apartments, builder floors, and commercial properties with RERA approval and transparent pricing." />
      </Helmet>

      <Header />

      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'Properties' }]} />
      </div>

      {/* Hero Section */}
      <section className="py-12 bg-gradient-to-br from-[#9c4915]/10 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Properties for Sale</h1>
            <p className="text-xl text-muted-foreground">
              Find your dream property from our curated collection of RERA approved listings
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filters & Actions */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-4">
              <Filter className="w-5 h-5 text-[#9c4915]" />
              <h2 className="text-xl font-bold">Filter Properties</h2>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" onClick={resetFilters} className="text-gray-600">
                Reset Filters
              </Button>
              <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-[#9c4915] hover:bg-[#7a3710]">
                    <Plus className="w-4 h-4 mr-2" /> Add New Property
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Property</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleAddProperty} className="space-y-4 mt-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Property Title *</Label>
                        <Input required value={newProperty.title} onChange={e => setNewProperty({...newProperty, title: e.target.value})} placeholder="e.g. Luxury 3 BHK Apartment" />
                      </div>
                      <div className="space-y-2">
                        <Label>Location *</Label>
                        <Select required value={newProperty.location} onValueChange={v => setNewProperty({...newProperty, location: v})}>
                          <SelectTrigger><SelectValue placeholder="Select Location" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Noida">Noida</SelectItem>
                            <SelectItem value="Greater Noida">Greater Noida</SelectItem>
                            <SelectItem value="Yamuna Expressway">Yamuna Expressway</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Property Type *</Label>
                        <Select required value={newProperty.type} onValueChange={v => setNewProperty({...newProperty, type: v})}>
                          <SelectTrigger><SelectValue placeholder="Select Type" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="High-Rise">High-Rise</SelectItem>
                            <SelectItem value="Builder Floor">Builder Floor</SelectItem>
                            <SelectItem value="Commercial">Commercial</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Price (in Lakhs) *</Label>
                        <Input type="number" required value={newProperty.price} onChange={e => setNewProperty({...newProperty, price: e.target.value})} placeholder="e.g. 85" />
                      </div>
                      <div className="space-y-2">
                        <Label>Carpet Area (sq.ft) *</Label>
                        <Input type="number" required value={newProperty.area} onChange={e => setNewProperty({...newProperty, area: e.target.value})} placeholder="e.g. 1450" />
                      </div>
                      <div className="space-y-2">
                        <Label>BHK *</Label>
                        <Select required value={newProperty.bhk} onValueChange={v => setNewProperty({...newProperty, bhk: v})}>
                          <SelectTrigger><SelectValue placeholder="Select BHK" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1 BHK</SelectItem>
                            <SelectItem value="2">2 BHK</SelectItem>
                            <SelectItem value="3">3 BHK</SelectItem>
                            <SelectItem value="4+">4 BHK+</SelectItem>
                            <SelectItem value="Office">Office</SelectItem>
                            <SelectItem value="Shop">Shop</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Status *</Label>
                        <Select required value={newProperty.status} onValueChange={v => setNewProperty({...newProperty, status: v})}>
                          <SelectTrigger><SelectValue placeholder="Select Status" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Ready to Move">Ready to Move</SelectItem>
                            <SelectItem value="Under Construction">Under Construction</SelectItem>
                            <SelectItem value="New Launch">New Launch</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>RERA Status *</Label>
                        <Select required value={newProperty.rera} onValueChange={v => setNewProperty({...newProperty, rera: v})}>
                          <SelectTrigger><SelectValue placeholder="Select RERA Status" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Yes">Yes</SelectItem>
                            <SelectItem value="No">No</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <Label>Property Image</Label>
                        <div className="flex flex-col gap-3">
                          <input 
                            type="file" 
                            accept="image/*" 
                            className="hidden" 
                            ref={fileInputRef}
                            onChange={handleImageUpload}
                          />
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => fileInputRef.current?.click()}
                            className="w-full border-dashed border-2 h-20 flex flex-col items-center justify-center text-gray-500 hover:text-[#9c4915] hover:border-[#9c4915]"
                          >
                            <Upload className="w-6 h-6 mb-1" />
                            <span>Click to upload image</span>
                          </Button>
                          {newProperty.image && (
                            <div className="relative w-full h-40 rounded-md overflow-hidden border">
                              <img src={newProperty.image} alt="Preview" className="w-full h-full object-cover" />
                              <button 
                                type="button"
                                onClick={() => setNewProperty({...newProperty, image: ''})}
                                className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <Label>Description</Label>
                        <Textarea value={newProperty.description} onChange={e => setNewProperty({...newProperty, description: e.target.value})} placeholder="Property description..." />
                      </div>
                    </div>
                    <Button type="submit" className="w-full bg-[#9c4915] hover:bg-[#7a3710]">Save Property</Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-6 gap-4">
            <Select value={filters.location} onValueChange={(v) => setFilters({...filters, location: v})}>
              <SelectTrigger><SelectValue placeholder="Location" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                <SelectItem value="noida">Noida</SelectItem>
                <SelectItem value="greater-noida">Greater Noida</SelectItem>
                <SelectItem value="yamuna">Yamuna Expressway</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.type} onValueChange={(v) => setFilters({...filters, type: v})}>
              <SelectTrigger><SelectValue placeholder="Property Type" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="high-rise">High-Rise</SelectItem>
                <SelectItem value="builder-floor">Builder Floor</SelectItem>
                <SelectItem value="commercial">Commercial</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.budget} onValueChange={(v) => setFilters({...filters, budget: v})}>
              <SelectTrigger><SelectValue placeholder="Budget Range" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Budgets</SelectItem>
                <SelectItem value="0-50">₹0 - ₹50 Lakhs</SelectItem>
                <SelectItem value="50-100">₹50 Lakhs - ₹1 Cr</SelectItem>
                <SelectItem value="100-200">₹1 Cr - ₹2 Cr</SelectItem>
                <SelectItem value="200+">₹2 Cr+</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.bhk} onValueChange={(v) => setFilters({...filters, bhk: v})}>
              <SelectTrigger><SelectValue placeholder="BHK" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All BHK</SelectItem>
                <SelectItem value="1">1 BHK</SelectItem>
                <SelectItem value="2">2 BHK</SelectItem>
                <SelectItem value="3">3 BHK</SelectItem>
                <SelectItem value="4">4 BHK</SelectItem>
                <SelectItem value="5+">5 BHK+</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.status} onValueChange={(v) => setFilters({...filters, status: v})}>
              <SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="ready-to-move">Ready to Move</SelectItem>
                <SelectItem value="under-construction">Under Construction</SelectItem>
                <SelectItem value="new-launch">New Launch</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.rera} onValueChange={(v) => setFilters({...filters, rera: v})}>
              <SelectTrigger><SelectValue placeholder="RERA Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All RERA</SelectItem>
                <SelectItem value="yes">RERA Approved</SelectItem>
                <SelectItem value="no">Not Approved</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="mt-6 text-sm text-gray-600 font-medium">
            Showing {filteredProperties.length} of {properties.length} properties
          </div>

          {selectedProperties.length > 0 && (
            <div className="mt-4 flex items-center justify-between bg-[#9c4915]/10 p-4 rounded-lg">
              <span className="font-semibold">
                {selectedProperties.length} {selectedProperties.length === 1 ? 'property' : 'properties'} selected for comparison
              </span>
              <Link to="/comparison">
                <Button className="bg-[#9c4915] hover:bg-[#7a3710]">
                  Compare Properties
                </Button>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Property Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {filteredProperties.length === 0 ? (
            <div className="text-center py-12">
              <h3 className="text-2xl font-bold text-gray-400">No properties found matching your criteria.</h3>
              <Button variant="outline" onClick={resetFilters} className="mt-4">Clear Filters</Button>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProperties.map((property, index) => (
                <motion.div
                  key={property.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card className="overflow-hidden hover:shadow-xl transition-shadow h-full">
                    <div className="relative h-48">
                      <img 
                        src={property.image} 
                        alt={property.title}
                        className="w-full h-full object-cover"
                      />
                      {property.rera.toLowerCase() === 'yes' && (
                        <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded text-xs font-semibold">
                          RERA
                        </div>
                      )}
                      <div className="absolute bottom-2 left-2 bg-blue-600 text-white px-2 py-1 rounded text-xs">
                        {property.status}
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <span className="text-[#9c4915] text-sm font-semibold">{property.type}</span>
                      <h3 className="text-xl font-bold mb-2">{property.title}</h3>
                      <div className="flex items-center gap-2 text-muted-foreground mb-3">
                        <MapPin className="w-4 h-4" />
                        <span className="text-sm">{property.location}</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 mb-4 text-sm">
                        <div className="flex items-center gap-1">
                          <Home className="w-4 h-4 text-[#9c4915]" />
                          <span>{property.bhk}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Maximize className="w-4 h-4 text-[#9c4915]" />
                          <span>{property.area}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <IndianRupee className="w-4 h-4 text-[#9c4915]" />
                          <span className="font-bold">{property.price}</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Link to={`/property/${property.id}`} className="flex-1">
                          <Button variant="outline" className="w-full border-[#9c4915] text-[#9c4915] hover:bg-[#9c4915] hover:text-white">
                            View Details
                          </Button>
                        </Link>
                        <Button
                          variant={selectedProperties.includes(property.id) ? "default" : "outline"}
                          size="icon"
                          onClick={() => handleAddToCompare(property.id)}
                          className={selectedProperties.includes(property.id) ? "bg-[#9c4915]" : ""}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </>
  );
};

export default PropertyListing;