import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Shield, Heart, Users, Lightbulb, Award, CheckCircle, FileCheck, MapPin } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';

const AboutUs = () => {
  const coreValues = [
    {
      icon: Shield,
      title: 'Transparency',
      description: 'Complete disclosure of property details, pricing, and documentation. No hidden charges or surprises.'
    },
    {
      icon: Award,
      title: 'Quality',
      description: 'Only RERA approved projects with verified builders and quality construction standards.'
    },
    {
      icon: Heart,
      title: 'Customer-First',
      description: 'Your satisfaction is our priority. Personalized service and lifetime support for all clients.'
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'Leveraging technology and market insights to provide the best property solutions.'
    }
  ];

  const whyChooseUs = [
    {
      icon: FileCheck,
      title: 'RERA Guidance',
      description: 'Expert assistance with RERA registered properties, ensuring complete legal compliance and buyer protection.'
    },
    {
      icon: MapPin,
      title: 'Site Visit Arrangements',
      description: 'Organized property tours with our experts, helping you make informed decisions after physical inspection.'
    },
    {
      icon: CheckCircle,
      title: 'Documentation Support',
      description: 'Complete assistance with property papers, registration, stamp duty, and home loan processing.'
    },
    {
      icon: Users,
      title: 'Transparent Process',
      description: 'Clear communication at every step, from property search to final handover and beyond.'
    }
  ];

  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Shri RK Homes",
    "description": "Premium real estate consultant in Noida, Greater Noida, and Yamuna Expressway offering RERA approved properties with transparent processes.",
    "url": "https://shrirkhomes.com/about",
    "logo": "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a5646/89b66dbe668adcc56bbba4265b131993.jpg",
    "foundingDate": "2015",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Noida",
      "addressRegion": "Uttar Pradesh",
      "addressCountry": "IN"
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+91-7303459116",
      "contactType": "customer service",
      "email": "sales@shrirkhomes.com"
    }
  };

  return (
    <>
      <Helmet>
        <title>About Shri RK Homes - Your Trusted Real Estate Partner in Noida</title>
        <meta name="description" content="Learn about Shri RK Homes, a leading real estate consultant in Noida offering RERA approved properties, transparent processes, and complete documentation support. Discover our mission, values, and commitment to excellence." />
        <meta name="keywords" content="about Shri RK Homes, real estate consultant Noida, RERA guidance, property documentation support, transparent real estate process, trusted property dealer Noida" />
        <link rel="canonical" href="https://shrirkhomes.com/about" />
        
        <meta property="og:title" content="About Shri RK Homes - Your Trusted Real Estate Partner" />
        <meta property="og:description" content="Leading real estate consultant in Noida with transparent processes and RERA compliance" />
        <meta property="og:url" content="https://shrirkhomes.com/about" />
        
        <script type="application/ld+json">
          {JSON.stringify(schemaMarkup)}
        </script>
      </Helmet>

      <Header />

      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'About Us' }]} />
      </div>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-[#9c4915]/10 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About Shri RK Homes</h1>
            <p className="text-xl text-muted-foreground">
              Your trusted partner for premium real estate solutions in Noida, Greater Noida, and Yamuna Expressway
            </p>
          </motion.div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-16">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <div className="prose prose-lg max-w-none text-gray-700 space-y-4">
                <p>
                  Shri RK Homes was founded with a simple yet powerful vision: to make real estate transactions transparent, trustworthy, and hassle-free for every client. What started as a small consultancy in Noida has grown into one of the most respected names in NCR real estate, serving hundreds of satisfied homeowners and investors.
                </p>
                <p>
                  Our journey began when our founders recognized a critical gap in the real estate market - the lack of transparency and customer-centric service. Too many buyers were facing challenges with unclear pricing, hidden charges, incomplete documentation, and unreliable builders. We set out to change this narrative by building a company that puts customer interests first, always.
                </p>
                <p>
                  Over the years, we have built strong relationships with RERA approved builders, developers, and financial institutions across Noida, Greater Noida, and Yamuna Expressway. This network enables us to offer our clients exclusive access to premium properties, competitive pricing, and flexible payment plans that suit diverse budgets and requirements.
                </p>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative h-[400px] rounded-xl overflow-hidden shadow-xl"
            >
              <img 
                src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1000&q=80" 
                alt="Shri RK Homes Team and Office" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Core Values</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              The principles that guide everything we do at Shri RK Homes
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {coreValues.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full text-center hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="w-16 h-16 bg-[#9c4915]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Icon className="w-8 h-8 text-[#9c4915]" />
                      </div>
                      <h3 className="text-xl font-bold mb-3">{value.title}</h3>
                      <p className="text-muted-foreground">{value.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Shri RK Homes?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive support and proven expertise that sets us apart
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {whyChooseUs.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-lg transition-shadow">
                    <CardContent className="p-6 flex gap-4">
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 bg-[#9c4915]/10 rounded-lg flex items-center justify-center">
                          <Icon className="w-6 h-6 text-[#9c4915]" />
                        </div>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                        <p className="text-muted-foreground">{item.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Detailed Content */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <article className="prose prose-lg max-w-none">
            <h2 className="text-3xl font-bold mb-6">Our Commitment to Excellence</h2>
            
            <p className="text-gray-700 mb-6">
              At Shri RK Homes, excellence is not just a goal—it's our standard operating procedure. Every property we recommend undergoes rigorous verification to ensure it meets our strict quality criteria. We personally visit construction sites, verify RERA registrations, check builder credentials, and review all legal documentation before presenting any property to our clients.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">RERA Compliance and Legal Assurance</h3>
            <p className="text-gray-700 mb-6">
              The Real Estate (Regulation and Development) Act, 2016 (RERA) was a game-changer for the Indian real estate sector, bringing much-needed transparency and accountability. At Shri RK Homes, we were early adopters of RERA compliance, and today, 100% of our listed properties are RERA registered. This means every project comes with verified approvals, clear timelines, and legal protection for buyers.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Personalized Property Consultation</h3>
            <p className="text-gray-700 mb-6">
              We understand that every client has unique requirements, budget constraints, and lifestyle preferences. That's why we don't believe in one-size-fits-all solutions. Our property consultants take time to understand your needs, whether you're a first-time homebuyer looking for a 2 BHK apartment in Noida, an investor seeking high-ROI commercial property on Yamuna Expressway, or a family searching for spacious builder floors in Greater Noida.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">End-to-End Transaction Support</h3>
            <p className="text-gray-700 mb-6">
              Buying property involves multiple steps—property search, site visits, price negotiation, documentation, home loan processing, registration, and possession. At Shri RK Homes, we provide comprehensive support at every stage. Our team includes property advisors, legal experts, financial consultants, and customer service professionals who work together to make your property buying journey smooth and stress-free.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Technology-Driven Solutions</h3>
            <p className="text-gray-700 mb-6">
              In today's digital age, we leverage technology to enhance customer experience. Our website features advanced property search filters, virtual tours, EMI calculators, affordability tools, and property comparison features. Clients can browse properties, schedule site visits, and track their transaction status online. We also provide regular market updates, investment insights, and property alerts through email and WhatsApp.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Post-Purchase Support</h3>
            <p className="text-gray-700 mb-6">
              Our relationship with clients doesn't end at property handover. We provide lifetime support for all property-related queries, assistance with property maintenance, rental management services, and help with future property transactions. Many of our clients return to us for their second and third property purchases, which is the biggest testament to our service quality.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Community and Social Responsibility</h3>
            <p className="text-gray-700 mb-6">
              Shri RK Homes believes in giving back to the community. We actively participate in local development initiatives, support educational programs, and contribute to environmental conservation efforts. We also educate first-time homebuyers about their rights under RERA, help them understand property documentation, and guide them through the complexities of real estate transactions.
            </p>

            <h3 className="text-2xl font-bold mb-4 mt-8">Awards and Recognition</h3>
            <p className="text-gray-700 mb-6">
              Our commitment to excellence has been recognized by industry bodies and satisfied clients alike. We have received multiple awards for customer service, ethical business practices, and contribution to the real estate sector. However, our greatest achievement is the trust and loyalty of our clients, many of whom refer their friends and family to us.
            </p>

            <div className="bg-[#9c4915]/10 p-6 rounded-lg mt-8">
              <h3 className="text-2xl font-bold mb-4">Join the Shri RK Homes Family</h3>
              <p className="text-gray-700 mb-4">
                Whether you're buying your first home, upgrading to a larger property, or making a strategic investment, Shri RK Homes is here to guide you every step of the way. Experience the difference of working with a real estate consultant who truly cares about your success.
              </p>
            </div>
          </article>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default AboutUs;