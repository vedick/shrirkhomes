import React, { useState, useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Building2, CheckCircle, ChevronLeft, ChevronRight, Plus, Upload, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import { useToast } from '@/hooks/use-toast';

const defaultProjects = [
  {
    id: 1,
    title: 'Skyline Residency',
    location: 'Sector 137, Noida',
    type: 'High-Rise',
    status: 'Ready to Move',
    rera: 'UPRERAPRJ12345',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1000&q=80',
    description: 'Luxury high-rise apartments with modern amenities and excellent connectivity',
    features: ['3/4 BHK', 'Swimming Pool', 'Gym', 'Clubhouse', '24/7 Security']
  },
  {
    id: 2,
    title: 'Green Valley Floors',
    location: 'Greater Noida West',
    type: 'Builder Floor',
    status: 'Under Construction',
    rera: 'UPRERAPRJ23456',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=80',
    description: 'Premium builder floors with freehold ownership and customizable designs',
    features: ['4/5 BHK', 'Private Parking', 'Terrace', 'Modular Kitchen', 'Freehold']
  },
  {
    id: 3,
    title: 'Business Hub Plaza',
    location: 'Yamuna Expressway',
    type: 'Commercial',
    status: 'New Launch',
    rera: 'UPRERAPRJ34567',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1000&q=80',
    description: 'Modern commercial complex with office spaces and retail shops',
    features: ['Office Spaces', 'Retail Shops', 'Food Court', 'Ample Parking', 'High ROI']
  }
];

const Projects = () => {
  const { toast } = useToast();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [projects, setProjects] = useState([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const fileInputRef = useRef(null);

  const [newProject, setNewProject] = useState({
    title: '', location: '', type: '', units: '', status: '', launchDate: '', possessionDate: '', priceFrom: '', priceTo: '', description: '', image: '', builder: '', rera: ''
  });

  useEffect(() => {
    const savedProjects = localStorage.getItem('rk_projects');
    if (savedProjects) {
      setProjects(JSON.parse(savedProjects));
    } else {
      setProjects(defaultProjects);
    }
  }, []);

  const nextSlide = () => {
    if (projects.length === 0) return;
    setCurrentSlide((prev) => (prev + 1) % projects.length);
  };

  const prevSlide = () => {
    if (projects.length === 0) return;
    setCurrentSlide((prev) => (prev - 1 + projects.length) % projects.length);
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast({ title: "Invalid file type", description: "Please upload an image file.", variant: "destructive" });
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewProject({ ...newProject, image: reader.result });
        toast({ title: "Image uploaded", description: "Image has been successfully attached." });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddProject = (e) => {
    e.preventDefault();
    const project = {
      id: Date.now(),
      title: newProject.title,
      location: newProject.location,
      type: newProject.type,
      status: newProject.status,
      rera: newProject.rera || 'Pending',
      image: newProject.image || 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=1000&q=80',
      description: newProject.description || 'New premium project by Shri RK Homes.',
      features: ['Premium Location', 'Modern Amenities', '24/7 Security']
    };

    const updatedProjects = [project, ...projects];
    setProjects(updatedProjects);
    localStorage.setItem('rk_projects', JSON.stringify(updatedProjects));
    setIsAddModalOpen(false);
    setNewProject({ title: '', location: '', type: '', units: '', status: '', launchDate: '', possessionDate: '', priceFrom: '', priceTo: '', description: '', image: '', builder: '', rera: '' });
    toast({ title: "Success", description: "Project added successfully!" });
  };

  return (
    <>
      <Helmet>
        <title>RERA Approved Projects in Noida, Greater Noida | Shri RK Homes</title>
        <meta name="description" content="Explore RERA approved real estate projects by Shri RK Homes in Noida, Greater Noida, and Yamuna Expressway." />
      </Helmet>

      <Header />

      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: 'Projects' }]} />
      </div>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-[#9c4915]/10 to-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">RERA Approved Projects</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Discover premium real estate projects across Noida, Greater Noida, and Yamuna Expressway
            </p>
            
            <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
              <DialogTrigger asChild>
                <Button className="bg-[#9c4915] hover:bg-[#7a3710] text-lg px-8 py-6">
                  <Plus className="w-5 h-5 mr-2" /> Add New Project
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Add New Project</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddProject} className="space-y-4 mt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Project Name *</Label>
                      <Input required value={newProject.title} onChange={e => setNewProject({...newProject, title: e.target.value})} placeholder="e.g. Skyline Residency" />
                    </div>
                    <div className="space-y-2">
                      <Label>Location *</Label>
                      <Select required value={newProject.location} onValueChange={v => setNewProject({...newProject, location: v})}>
                        <SelectTrigger><SelectValue placeholder="Select Location" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Noida">Noida</SelectItem>
                          <SelectItem value="Greater Noida">Greater Noida</SelectItem>
                          <SelectItem value="Yamuna Expressway">Yamuna Expressway</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Project Type *</Label>
                      <Select required value={newProject.type} onValueChange={v => setNewProject({...newProject, type: v})}>
                        <SelectTrigger><SelectValue placeholder="Select Type" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="High-Rise">High-Rise</SelectItem>
                          <SelectItem value="Builder Floor">Builder Floor</SelectItem>
                          <SelectItem value="Commercial">Commercial</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Total Units *</Label>
                      <Input type="number" required value={newProject.units} onChange={e => setNewProject({...newProject, units: e.target.value})} placeholder="e.g. 250" />
                    </div>
                    <div className="space-y-2">
                      <Label>Status *</Label>
                      <Select required value={newProject.status} onValueChange={v => setNewProject({...newProject, status: v})}>
                        <SelectTrigger><SelectValue placeholder="Select Status" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Planning">Planning</SelectItem>
                          <SelectItem value="Under Construction">Under Construction</SelectItem>
                          <SelectItem value="Ready to Move">Ready to Move</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>RERA Number</Label>
                      <Input value={newProject.rera} onChange={e => setNewProject({...newProject, rera: e.target.value})} placeholder="e.g. UPRERAPRJ..." />
                    </div>
                    <div className="space-y-2">
                      <Label>Launch Date</Label>
                      <Input type="date" value={newProject.launchDate} onChange={e => setNewProject({...newProject, launchDate: e.target.value})} />
                    </div>
                    <div className="space-y-2">
                      <Label>Possession Date</Label>
                      <Input type="date" value={newProject.possessionDate} onChange={e => setNewProject({...newProject, possessionDate: e.target.value})} />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label>Project Image</Label>
                      <div className="flex flex-col gap-3">
                        <input 
                          type="file" 
                          accept="image/*" 
                          className="hidden" 
                          ref={fileInputRef}
                          onChange={handleImageUpload}
                        />
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => fileInputRef.current?.click()}
                          className="w-full border-dashed border-2 h-20 flex flex-col items-center justify-center text-gray-500 hover:text-[#9c4915] hover:border-[#9c4915]"
                        >
                          <Upload className="w-6 h-6 mb-1" />
                          <span>Click to upload image</span>
                        </Button>
                        {newProject.image && (
                          <div className="relative w-full h-40 rounded-md overflow-hidden border">
                            <img src={newProject.image} alt="Preview" className="w-full h-full object-cover" />
                            <button 
                              type="button"
                              onClick={() => setNewProject({...newProject, image: ''})}
                              className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label>Description</Label>
                      <Textarea value={newProject.description} onChange={e => setNewProject({...newProject, description: e.target.value})} placeholder="Project description..." />
                    </div>
                  </div>
                  <Button type="submit" className="w-full bg-[#9c4915] hover:bg-[#7a3710]">Save Project</Button>
                </form>
              </DialogContent>
            </Dialog>
          </motion.div>
        </div>
      </section>

      {/* Project Slideshow */}
      {projects.length > 0 && (
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="relative">
                <motion.div
                  key={currentSlide}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="overflow-hidden">
                    <div className="grid md:grid-cols-2">
                      <div className="relative h-64 md:h-96">
                        <img 
                          src={projects[currentSlide].image} 
                          alt={projects[currentSlide].title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                          RERA Approved
                        </div>
                        <div className="absolute bottom-4 left-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                          {projects[currentSlide].status}
                        </div>
                      </div>
                      <CardContent className="p-8">
                        <span className="text-[#9c4915] font-semibold">{projects[currentSlide].type}</span>
                        <h2 className="text-3xl font-bold mb-2">{projects[currentSlide].title}</h2>
                        <div className="flex items-center gap-2 text-muted-foreground mb-4">
                          <MapPin className="w-4 h-4" />
                          <span>{projects[currentSlide].location}</span>
                        </div>
                        <p className="text-gray-700 mb-6">{projects[currentSlide].description}</p>
                        <div className="mb-6">
                          <p className="font-semibold mb-2">Key Features:</p>
                          <div className="flex flex-wrap gap-2">
                            {projects[currentSlide].features?.map((feature, idx) => (
                              <span key={idx} className="px-3 py-1 bg-gray-100 rounded-full text-sm">
                                {feature}
                              </span>
                            ))}
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-4">
                          RERA No: {projects[currentSlide].rera}
                        </p>
                        <Link to={`/property/${projects[currentSlide].id}`}>
                          <Button className="bg-[#9c4915] hover:bg-[#7a3710] w-full">
                            View Details
                          </Button>
                        </Link>
                      </CardContent>
                    </div>
                  </Card>
                </motion.div>

                {/* Slideshow Controls */}
                <button
                  onClick={prevSlide}
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-3 rounded-full shadow-lg"
                  aria-label="Previous project"
                >
                  <ChevronLeft className="w-6 h-6 text-[#9c4915]" />
                </button>
                <button
                  onClick={nextSlide}
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-3 rounded-full shadow-lg"
                  aria-label="Next project"
                >
                  <ChevronRight className="w-6 h-6 text-[#9c4915]" />
                </button>

                {/* Dots */}
                <div className="flex justify-center gap-2 mt-6">
                  {projects.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentSlide(index)}
                      className={`w-3 h-3 rounded-full transition-all ${
                        index === currentSlide ? 'bg-[#9c4915] w-8' : 'bg-gray-300'
                      }`}
                      aria-label={`Go to project ${index + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Project Grid with Filters */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">All Projects</h2>
          
          <Tabs defaultValue="all" className="max-w-6xl mx-auto">
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="all">All Projects</TabsTrigger>
              <TabsTrigger value="high-rise">High-Rise</TabsTrigger>
              <TabsTrigger value="builder-floor">Builder Floors</TabsTrigger>
              <TabsTrigger value="commercial">Commercial</TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {projects.map((project, index) => (
                  <motion.div
                    key={project.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="overflow-hidden hover:shadow-xl transition-shadow h-full">
                      <div className="relative h-48">
                        <img 
                          src={project.image} 
                          alt={project.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded text-xs font-semibold">
                          RERA
                        </div>
                      </div>
                      <CardContent className="p-6">
                        <span className="text-[#9c4915] text-sm font-semibold">{project.type}</span>
                        <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                        <div className="flex items-center gap-2 text-muted-foreground mb-3">
                          <MapPin className="w-4 h-4" />
                          <span className="text-sm">{project.location}</span>
                        </div>
                        <div className="flex items-center gap-2 mb-4">
                          <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">
                            {project.status}
                          </span>
                        </div>
                        <Link to={`/property/${project.id}`}>
                          <Button variant="outline" className="w-full border-[#9c4915] text-[#9c4915] hover:bg-[#9c4915] hover:text-white">
                            View Details
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {['high-rise', 'builder-floor', 'commercial'].map((type) => (
              <TabsContent key={type} value={type}>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {projects
                    .filter((p) => p.type.toLowerCase().replace(' ', '-').includes(type))
                    .map((project) => (
                      <Card key={project.id} className="overflow-hidden hover:shadow-xl transition-shadow">
                        <div className="relative h-48">
                          <img 
                            src={project.image} 
                            alt={project.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <CardContent className="p-6">
                          <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                          <p className="text-muted-foreground mb-4">{project.location}</p>
                          <Link to={`/property/${project.id}`}>
                            <Button className="w-full bg-[#9c4915] hover:bg-[#7a3710]">
                              View Details
                            </Button>
                          </Link>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      <Footer />
    </>
  );
};

export default Projects;