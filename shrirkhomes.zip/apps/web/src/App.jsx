import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop';
import { Toaster } from '@/components/ui/toaster';

// Pages
import HomePage from './pages/HomePage';
import AboutUs from './pages/AboutUs';
import MissionVision from './pages/MissionVision';
import FoundersCut from './pages/FoundersCut';
import Services from './pages/Services';
import Projects from './pages/Projects';
import PropertyListing from './pages/PropertyListing';
import PropertyDetail from './pages/PropertyDetail';
import Contact from './pages/Contact';
import FinancialCalculators from './pages/FinancialCalculators';
import PropertyComparison from './pages/PropertyComparison';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';
import Disclaimer from './pages/Disclaimer';
import Blog from './pages/Blog';

function App() {
    return (
        <Router>
            <ScrollToTop />
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/about" element={<AboutUs />} />
                <Route path="/mission-vision" element={<MissionVision />} />
                <Route path="/founders-cut" element={<FoundersCut />} />
                <Route path="/services" element={<Services />} />
                <Route path="/projects" element={<Projects />} />
                <Route path="/properties" element={<PropertyListing />} />
                <Route path="/property/:id" element={<PropertyDetail />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/calculators" element={<FinancialCalculators />} />
                <Route path="/comparison" element={<PropertyComparison />} />
                <Route path="/privacy" element={<Privacy />} />
                <Route path="/terms" element={<Terms />} />
                <Route path="/disclaimer" element={<Disclaimer />} />
                <Route path="/blog" element={<Blog />} />
            </Routes>
            <Toaster />
        </Router>
    );
}

export default App;