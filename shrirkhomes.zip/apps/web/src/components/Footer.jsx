import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Facebook, Linkedin, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { name: 'Home', path: '/' },
    { name: 'About Us', path: '/about' },
    { name: "Founder's Cut", path: '/founders-cut' },
    { name: 'Mission & Vision', path: '/mission-vision' },
    { name: 'Services', path: '/services' },
    { name: 'Projects', path: '/projects' },
    { name: 'Properties', path: '/properties' },
    { name: 'Calculators', path: '/calculators' },
    { name: 'Comparison Tool', path: '/comparison' },
    { name: 'Contact', path: '/contact' },
    { name: 'Blog', path: '/blog' },
  ];

  const serviceAreas = [
    { name: 'Properties in Noida', path: '/properties?location=noida' },
    { name: 'Properties in Greater Noida', path: '/properties?location=greater-noida' },
    { name: 'Properties on Yamuna Expressway', path: '/properties?location=yamuna-expressway' },
  ];

  const legalLinks = [
    { name: 'Privacy Policy', path: '/privacy' },
    { name: 'Terms & Conditions', path: '/terms' },
    { name: 'Disclaimer', path: '/disclaimer' },
  ];

  const socialLinks = [
    { name: 'LinkedIn', icon: Linkedin, url: 'https://www.linkedin.com/in/amit-barthwal-6348b815' },
    { name: 'Facebook', icon: Facebook, url: 'https://facebook.com/shrirkhomes' },
    { name: 'Instagram', icon: Instagram, url: 'https://instagram.com/shrirkhomes_with_amit' },
  ];

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <Link to="/" className="inline-block mb-6 group">
              <div className="flex items-center gap-3">
                <img 
                  src="https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/89b66dbe668adcc56bbba4265b131993.jpg" 
                  alt="Shri RK Homes Logo" 
                  className="h-16 w-auto object-contain bg-white rounded-lg p-1"
                />
                <div className="flex flex-col">
                  <span className="text-2xl font-bold text-white tracking-tight">Shri RK Homes</span>
                  <span className="text-[10px] font-regular text-white tracking-wider mt-0.5">TOGETHER, TOWARDS A BETTER TOMORROW</span>
                </div>
              </div>
            </Link>
            <p className="text-sm mb-6 leading-relaxed">Your trusted partner in premium real estate across Noida, Greater Noida, and Yamuna Expressway. We help you find the perfect home or investment.</p>
            <div className="flex space-x-3">
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.name}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-gray-800 hover:bg-[#9c4915] rounded-full flex items-center justify-center transition-colors text-white"
                    aria-label={social.name}
                  >
                    <Icon className="w-5 h-5" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <p className="text-lg font-semibold text-white mb-4">Quick Links</p>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link 
                    to={link.path} 
                    className="text-sm hover:text-[#9c4915] transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <p className="text-lg font-semibold text-white mb-4">Service Areas</p>
            <ul className="space-y-2 mb-6">
              {serviceAreas.map((area) => (
                <li key={area.path}>
                  <Link 
                    to={area.path} 
                    className="text-sm hover:text-[#9c4915] transition-colors"
                  >
                    {area.name}
                  </Link>
                </li>
              ))}
            </ul>
            <p className="text-lg font-semibold text-white mb-4">Legal</p>
            <ul className="space-y-2">
              {legalLinks.map((link) => (
                <li key={link.path}>
                  <Link 
                    to={link.path} 
                    className="text-sm hover:text-[#9c4915] transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <p className="text-lg font-semibold text-white mb-4">Contact Us</p>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-[#9c4915] flex-shrink-0 mt-0.5" />
                <span className="text-sm leading-relaxed">T3-114, Golden-I, Techzone 4, Greater Noida West, UP-201304</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-[#9c4915] flex-shrink-0" />
                <a href="tel:+917303459116" className="text-sm hover:text-[#9c4915] transition-colors">
                  +91 7303459116
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-[#9c4915] flex-shrink-0" />
                <a href="mailto:sales@shrirkhomes.com" className="text-sm hover:text-[#9c4915] transition-colors">
                  sales@shrirkhomes.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-sm text-white">
            © {currentYear} Shri RK Homes. All rights reserved. | RERA Registered Real Estate Consultant | Powered By Stellars Estates
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;