import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

const partners = [
  { id: 1, name: "Sobha Realty", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/sobha-g8gsr.png" },
  { id: 2, name: "Experion Developers", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/experion-developers-1ShHS.png" },
  { id: 3, name: "Ace Group", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/ace-logo-8RPxm.png" },
  { id: 4, name: "Ashtech", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/ashtech-logo-82T3L.png" },
  { id: 5, name: "Mahagun Developers", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/mahagun-xXcuS.png" },
  { id: 6, name: "Godrej Properties", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/godrej-ZYEyn.png" },
  { id: 7, name: "Gaur Group", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/gaur-group-M2yrt.png" },
  { id: 8, name: "CRC Group", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/crc-logo-new-yJW6r.png" },
  { id: 9, name: "M3M Group", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/m3m-gTwer.png" },
  { id: 10, name: "VVIP", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/vvip-kzaIl.png" },
  { id: 11, name: "Eldeco", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/eldeco-XznXW.png" },
  { id: 12, name: "Prateek Group", logo: "https://horizons-cdn.hostinger.com/244718ad-7c46-496f-a3a1-8fc7f3a56469/prateek_logo-T9wuQ.png" },
];

const BrandPartnersSlideshow = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemsToShow, setItemsToShow] = useState(4);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 640) setItemsToShow(1);
      else if (window.innerWidth < 1024) setItemsToShow(2);
      else setItemsToShow(4);
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide();
    }, 3500);

    return () => clearInterval(interval);
  }, [currentIndex, itemsToShow]);

  const nextSlide = () => {
    setCurrentIndex((prev) =>
      (prev + 1) % Math.max(1, partners.length - itemsToShow + 1)
    );
  };

  const prevSlide = () => {
    setCurrentIndex((prev) =>
      prev === 0 ? Math.max(0, partners.length - itemsToShow) : prev - 1
    );
  };

  const visiblePartners = partners.slice(
    currentIndex,
    currentIndex + itemsToShow
  );

  if (visiblePartners.length < itemsToShow) {
    visiblePartners.push(
      ...partners.slice(0, itemsToShow - visiblePartners.length)
    );
  }

  return (
    <section className="py-12 bg-white border-b border-gray-100 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-gray-800">
            Our Trusted Partners
          </h3>
          <p className="text-gray-500 mt-2">
            Collaborating with the best in the industry
          </p>
        </div>

        <div className="relative max-w-6xl mx-auto px-12">
          <div className="flex gap-6 justify-center items-center min-h-[120px]">
            <AnimatePresence mode="popLayout">
              {visiblePartners.map((partner, idx) => (
                <motion.div
                  key={`${partner.id}-${currentIndex}-${idx}`}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.4 }}
                  className="flex-1 min-w-[200px]"
                >
                  <div className="w-33 h-24 rounded-xl bg-white flex items-center justify-center shadow-md hover:shadow-lg transition-shadow cursor-pointer group border">
                    
                    {partner.logo ? (
                      <img
                        src={partner.logo}
                        alt={partner.name}
                        className="h-full w-auto object-contain group-hover:scale-105 transition-transform"
                        onError={(e) => {
                          e.currentTarget.style.display = "none";
                        }}
                      />
                    ) : (
                      <span className="text-gray-700 font-semibold text-sm text-center px-2">
                        {partner.name}
                      </span>
                    )}

                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-white border shadow-md rounded-full flex items-center justify-center text-gray-600 hover:text-black transition z-10"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-white border shadow-md rounded-full flex items-center justify-center text-gray-600 hover:text-black transition z-10"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default BrandPartnersSlideshow;