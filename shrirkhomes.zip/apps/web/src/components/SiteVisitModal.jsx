import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const SiteVisitModal = ({ isOpen, onClose }) => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    interest: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value) => {
    setFormData(prev => ({ ...prev, interest: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Site Visit Scheduled!",
        description: `Your visit is confirmed for ${formData.date} at ${formData.time}. We will contact you shortly.`,
      });
      setFormData({ name: '', email: '', phone: '', date: '', time: '', interest: '' });
      onClose();
    }, 1000);
  };

  // Get tomorrow's date as the minimum date for the picker
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDate = tomorrow.toISOString().split('T')[0];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-blue-700">Schedule a Site Visit</DialogTitle>
          <DialogDescription>
            Book a guided tour of our premium properties with our real estate experts.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="visit-name">Full Name *</Label>
            <Input 
              id="visit-name" 
              name="name" 
              required 
              value={formData.name} 
              onChange={handleChange} 
              placeholder="Sahil Sharma" 
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="visit-email">Email Address *</Label>
              <Input 
                id="visit-email" 
                name="email" 
                type="email" 
                required 
                value={formData.email} 
                onChange={handleChange} 
                placeholder="sahil@example.com" 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="visit-phone">Phone Number *</Label>
              <Input 
                id="visit-phone" 
                name="phone" 
                type="tel" 
                required 
                value={formData.phone} 
                onChange={handleChange} 
                placeholder="+91 93109 71677" 
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="visit-interest">Property of Interest *</Label>
            <Select required value={formData.interest} onValueChange={handleSelectChange}>
              <SelectTrigger>
                <SelectValue placeholder="Select Property" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Residential">Residential</SelectItem>
                <SelectItem value="Commercial">Commercial</SelectItem>
                <SelectItem value="Builder Floor">Builder Floor</SelectItem>
                <SelectItem value="undecided">Not sure yet, want to explore</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="pt-4 flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={isSubmitting}>
              {isSubmitting ? 'Scheduling...' : 'Confirm Visit'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default SiteVisitModal;