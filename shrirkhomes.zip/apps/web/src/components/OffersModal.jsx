import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Gift, Percent, ShieldCheck, Clock } from 'lucide-react';

const OffersModal = ({ isOpen, onClose }) => {
  const offers = [
    {
      icon: Percent,
      title: "Special Festive Discount",
      description: "Get best discount offer on basic selling price for bookings made this month.",
      color: "text-green-600",
      bgColor: "bg-green-100"
    },
    {
      icon: Clock,
      title: "Flexible Payment Plan",
      description: "Pay 20% now and Get 80% loan from all major banks and nbfcs.",
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      icon: Gift,
      title: "Complimentary Modular Kitchen",
      description: "Free fully-fitted modular kitchen with every 3 BHK & 4 BHK booking.",
      color: "text-purple-600",
      bgColor: "bg-purple-100"
    },
    {
      icon: ShieldCheck,
      title: "Free Maintenance",
      description: "Enjoy 1 year of free society maintenance on ready-to-move properties.",
      color: "text-orange-600",
      bgColor: "bg-orange-100"
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold text-green-700 flex items-center gap-2">
            <Gift className="w-8 h-8" />
            Exclusive Offers & Deals
          </DialogTitle>
          <DialogDescription className="text-base">
            Take advantage of our limited-time offers and flexible payment plans to make your dream home a reality.
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          {offers.map((offer, index) => {
            const Icon = offer.icon;
            return (
              <Card key={index} className="border-2 hover:border-green-500 transition-colors">
                <CardHeader className="pb-2">
                  <div className={`w-12 h-12 rounded-full ${offer.bgColor} flex items-center justify-center mb-3`}>
                    <Icon className={`w-6 h-6 ${offer.color}`} />
                  </div>
                  <CardTitle className="text-lg">{offer.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{offer.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-6 bg-gray-50 p-4 rounded-lg border text-center">
          <p className="text-sm text-gray-600 mb-4">
            *Terms and conditions apply. Offers are subject to change without prior notice and are applicable on select properties only.
          </p>
          <Button onClick={onClose} className="bg-green-600 hover:bg-green-700 w-full sm:w-auto">
            Got it, Thanks!
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default OffersModal;